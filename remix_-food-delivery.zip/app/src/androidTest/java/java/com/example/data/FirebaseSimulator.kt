package com.example.data

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.example.model.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class FirebaseSimulator private constructor(context: Context) {

    private val sharedPrefs = context.applicationContext.getSharedPreferences("food_delivery_firebase_mock", Context.MODE_PRIVATE)
    private val mainScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val appCtx = context.applicationContext

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    // Flow states
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _foods = MutableStateFlow<List<FoodItem>>(emptyList())
    val foods: StateFlow<List<FoodItem>> = _foods.asStateFlow()

    private val _favorites = MutableStateFlow<Set<String>>(emptySet())
    val favorites: StateFlow<Set<String>> = _favorites.asStateFlow()

    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _reviews = MutableStateFlow<List<Review>>(emptyList())
    val reviews: StateFlow<List<Review>> = _reviews.asStateFlow()

    private val _notifications = MutableStateFlow<List<Notification>>(emptyList())
    val notifications: StateFlow<List<Notification>> = _notifications.asStateFlow()

    // Temporary OTP state
    private val _otpTimer = MutableStateFlow(0)
    val otpTimer: StateFlow<Int> = _otpTimer.asStateFlow()
    private var otpJob: Job? = null
    private var simulatedOtp = ""
    private var activeMobile = ""

    init {
        loadData()
        simulateLiveOrdersOnLaunch()
    }

    private fun loadData() {
        try {
            // Load User
            val userJson = sharedPrefs.getString("user_v1", null)
            if (userJson != null) {
                val adapter = moshi.adapter(User::class.java)
                _currentUser.value = adapter.fromJson(userJson)
            }

            // Load theme & dynamic foods
            _isDarkMode.value = sharedPrefs.getBoolean("theme_dark_mode", false)

            val foodsJson = sharedPrefs.getString("foods_v2", null)
            if (foodsJson != null) {
                val type = Types.newParameterizedType(List::class.java, FoodItem::class.java)
                val adapter = moshi.adapter<List<FoodItem>>(type)
                _foods.value = adapter.fromJson(foodsJson) ?: emptyList()
            } else {
                _foods.value = emptyList() // Default is empty as requested!
            }

            // Load Favorites
            val favsSet = sharedPrefs.getStringSet("favorites_v1", emptySet()) ?: emptySet()
            _favorites.value = favsSet

            // Load Reviews (We pre-populate if empty)
            val reviewsJson = sharedPrefs.getString("reviews_v1", null)
            if (reviewsJson != null) {
                val type = Types.newParameterizedType(List::class.java, Review::class.java)
                val adapter = moshi.adapter<List<Review>>(type)
                _reviews.value = adapter.fromJson(reviewsJson) ?: emptyList()
            } else {
                // Populate default reviews
                val defaultReviews = listOf(
                    Review(
                        id = "rev_1",
                        foodItemId = "food_burger_1",
                        userName = "Michael Thorne",
                        rating = 5.0,
                        comment = "Hands down the best double cheese smokehouse burger in town! It was juicy, the onions rings were crispy, and BBQ sauce was spectacular.",
                        timestamp = System.currentTimeMillis() - 86400000
                    ),
                    Review(
                        id = "rev_2",
                        foodItemId = "food_burger_1",
                        userName = "Elena Petrova",
                        rating = 4.5,
                        comment = "Amazing bun and perfectly cooked beef. Will definitely order again! Delivery was quick too.",
                        timestamp = System.currentTimeMillis() - 43200000
                    ),
                    Review(
                        id = "rev_3",
                        foodItemId = "food_pizza_2",
                        userName = "Siddharth Mehta",
                        rating = 5.0,
                        comment = "Best hand-stretched thin sourdough pepperoni pizza ever. Incredible smoky flavor, basil leaves tasted super aromatic.",
                        timestamp = System.currentTimeMillis() - 3600000
                    )
                )
                _reviews.value = defaultReviews
                saveReviews()
            }

            // Load Notifications (We pre-populate if empty)
            val notifsJson = sharedPrefs.getString("notifications_v1", null)
            if (notifsJson != null) {
                val type = Types.newParameterizedType(List::class.java, Notification::class.java)
                val adapter = moshi.adapter<List<Notification>>(type)
                _notifications.value = adapter.fromJson(notifsJson) ?: emptyList()
            } else {
                val initialNotif = listOf(
                    Notification(
                        id = "notif_welcome",
                        title = "Welcome to Food Delivery!",
                        message = "Unlock mega savings of up to 40% on your first 3 code-exclusive orders. Happy feasting!",
                        type = "PROMOTION",
                        timestamp = System.currentTimeMillis()
                    )
                )
                _notifications.value = initialNotif
                saveNotifications()
            }

            // Load Cart
            val cartJson = sharedPrefs.getString("cart_v1", null)
            if (cartJson != null) {
                val type = Types.newParameterizedType(List::class.java, CartItem::class.java)
                val adapter = moshi.adapter<List<CartItem>>(type)
                _cart.value = adapter.fromJson(cartJson) ?: emptyList()
            }

            // Load Orders
            val ordersJson = sharedPrefs.getString("orders_v1", null)
            if (ordersJson != null) {
                val type = Types.newParameterizedType(List::class.java, Order::class.java)
                val adapter = moshi.adapter<List<Order>>(type)
                _orders.value = adapter.fromJson(ordersJson) ?: emptyList()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // --- Core Persists ---
    private fun saveUser() {
        val json = moshi.adapter(User::class.java).toJson(_currentUser.value)
        sharedPrefs.edit().putString("user_v1", json).apply()
    }

    private fun saveFavorites() {
        sharedPrefs.edit().putStringSet("favorites_v1", _favorites.value).apply()
    }

    private fun saveCart() {
        val type = Types.newParameterizedType(List::class.java, CartItem::class.java)
        val json = moshi.adapter<List<CartItem>>(type).toJson(_cart.value)
        sharedPrefs.edit().putString("cart_v1", json).apply()
    }

    private fun saveOrders() {
        val type = Types.newParameterizedType(List::class.java, Order::class.java)
        val json = moshi.adapter<List<Order>>(type).toJson(_orders.value)
        sharedPrefs.edit().putString("orders_v1", json).apply()
    }

    private fun saveReviews() {
        val type = Types.newParameterizedType(List::class.java, Review::class.java)
        val json = moshi.adapter<List<Review>>(type).toJson(_reviews.value)
        sharedPrefs.edit().putString("reviews_v1", json).apply()
    }

    private fun saveNotifications() {
        val type = Types.newParameterizedType(List::class.java, Notification::class.java)
        val json = moshi.adapter<List<Notification>>(type).toJson(_notifications.value)
        sharedPrefs.edit().putString("notifications_v1", json).apply()
    }

    // --- Authentication Simulator ---
    fun sendFirebaseOtp(mobileNumber: String, onOtpSent: (String) -> Unit) {
        activeMobile = mobileNumber
        simulatedOtp = (100000..999999).random().toString()
        onOtpSent(simulatedOtp)

        // Cancel existing timers
        otpJob?.cancel()
        _otpTimer.value = 60
        otpJob = mainScope.launch {
            while (_otpTimer.value > 0) {
                delay(1000)
                _otpTimer.value -= 1
            }
        }

        // Trigger SMS delivery simulation notification after 3 seconds
        mainScope.launch {
            delay(3000)
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(
                    appCtx,
                    "[SMS Simulator] SMS OTP details received: $simulatedOtp. Auto-detected!",
                    Toast.LENGTH_LONG
                ).show()
                // Directly trigger notification
                triggerNotification(
                    title = "OTP Auto-Detected!",
                    message = "Simulated Android Phone verification detected OTP code $simulatedOtp successfully.",
                    type = "SYSTEM"
                )
            }
        }
    }

    fun resendFirebaseOtp(onOtpSent: (String) -> Unit) {
        if (activeMobile.isNotEmpty()) {
            sendFirebaseOtp(activeMobile, onOtpSent)
        }
    }

    fun verifyFirebaseOtp(code: String, onSuccess: (user: User) -> Unit, onFailure: (String) -> Unit) {
        if (code == "123456" || code == simulatedOtp) {
            val loadedUser = _currentUser.value
            if (loadedUser != null && loadedUser.mobile == activeMobile) {
                // Return persistent user
                onSuccess(loadedUser)
            } else {
                // Return uncompleted initial user
                val newUser = User(mobile = activeMobile, isRegistered = false)
                _currentUser.value = newUser
                saveUser()
                onSuccess(newUser)
            }
        } else {
            onFailure("Invalid 6-digit confirmation code. Please enter the correct code.")
        }
    }

    fun registerNewUser(fullName: String, email: String, profilePhotoUrl: String) {
        val u = _currentUser.value ?: User(mobile = activeMobile)
        val updated = u.copy(
            fullName = fullName,
            email = email,
            profilePhotoUrl = profilePhotoUrl.ifBlank { "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&q=80" },
            isRegistered = true
        )
        _currentUser.value = updated
        saveUser()
    }

    fun logout() {
        _currentUser.value = null
        _cart.value = emptyList()
        _favorites.value = emptySet()
        sharedPrefs.edit()
            .remove("user_v1")
            .remove("cart_v1")
            .remove("favorites_v1")
            .apply()
    }

    // --- Profile Editing ---
    fun updateProfile(fullName: String, email: String, profilePhotoUrl: String, address: String, landmark: String) {
        val curr = _currentUser.value ?: return
        val updated = curr.copy(
            fullName = fullName,
            email = email,
            profilePhotoUrl = profilePhotoUrl,
            defaultAddress = address,
            defaultLandmark = landmark
        )
        _currentUser.value = updated
        saveUser()
    }

    // --- Favorites Simulator ---
    fun toggleFavorite(foodId: String) {
        val currentSet = _favorites.value.toMutableSet()
        if (currentSet.contains(foodId)) {
            currentSet.remove(foodId)
        } else {
            currentSet.add(foodId)
        }
        _favorites.value = currentSet
        saveFavorites()
    }

    // --- Cart Actions ---
    fun addToCart(foodItem: FoodItem, quantity: Int = 1) {
        val currentList = _cart.value.toMutableList()
        val index = currentList.indexOfFirst { it.foodItem.id == foodItem.id }
        if (index != -1) {
            val matchedItem = currentList[index]
            val updatedQty = matchedItem.quantity + quantity
            if (updatedQty <= 0) {
                currentList.removeAt(index)
            } else {
                currentList[index] = matchedItem.copy(quantity = updatedQty)
            }
        } else if (quantity > 0) {
            currentList.add(CartItem(id = UUID.randomUUID().toString(), foodItem = foodItem, quantity = quantity))
        }
        _cart.value = currentList
        saveCart()
    }

    fun updateCartQuantity(foodId: String, delta: Int) {
        val currentList = _cart.value.toMutableList()
        val index = currentList.indexOfFirst { it.foodItem.id == foodId }
        if (index != -1) {
            val matchedItem = currentList[index]
            val updatedQty = matchedItem.quantity + delta
            if (updatedQty <= 0) {
                currentList.removeAt(index)
            } else {
                currentList[index] = matchedItem.copy(quantity = updatedQty)
            }
        }
        _cart.value = currentList
        saveCart()
    }

    fun removeCartItem(foodId: String) {
        val currentList = _cart.value.filter { it.foodItem.id != foodId }
        _cart.value = currentList
        saveCart()
    }

    fun clearCart() {
        _cart.value = emptyList()
        saveCart()
    }

    // --- Placed Orders / Live Simulation Engine ---
    fun placeOrder(
        fullName: String,
        mobileNumber: String,
        deliveryAddress: String,
        landmark: String,
        notes: String,
        customerLat: Double,
        customerLng: Double
    ): Order {
        val cartItems = _cart.value
        val subtotal = cartItems.sumOf { it.foodItem.price * it.quantity }
        val delivery = if (subtotal > 30.0) 0.0 else 2.99
        val total = subtotal + delivery

        val orderId = "ORD-${(10000..99999).random()}"
        val newOrder = Order(
            id = orderId,
            items = cartItems,
            subtotal = subtotal,
            deliveryCharges = delivery,
            total = total,
            name = fullName,
            mobile = mobileNumber,
            deliveryAddress = deliveryAddress,
            landmark = landmark,
            notes = notes,
            status = OrderStatus.PENDING,
            timestamp = System.currentTimeMillis(),
            estimatedMinutes = 35,
            customerLat = customerLat,
            customerLng = customerLng
        )

        // Prepend new order
        val updatedOrders = listOf(newOrder) + _orders.value
        _orders.value = updatedOrders
        saveOrders()

        // Sync main user profile address shortcuts if empty
        val user = _currentUser.value
        if (user != null && (user.defaultAddress.isBlank() || user.fullName.isBlank())) {
            _currentUser.value = user.copy(
                fullName = user.fullName.ifBlank { fullName },
                defaultAddress = user.defaultAddress.ifBlank { deliveryAddress },
                defaultLandmark = user.defaultLandmark.ifBlank { landmark }
            )
            saveUser()
        }

        clearCart()
        triggerNotification(
            title = "Order Placed Successfully",
            message = "Your order $orderId has been received. Sit back while we request confirmation from the restaurant.",
            type = "ORDER",
            orderId = orderId
        )

        // Launch background life simulator for this order
        startOrderTimelineSimulation(orderId)

        return newOrder
    }

    fun reorder(order: Order) {
        // Add items back into cart
        clearCart()
        for (item in order.items) {
            addToCart(item.foodItem, item.quantity)
        }
    }

    private fun startOrderTimelineSimulation(orderId: String) {
        mainScope.launch {
            // PENDING -> ACCEPTED (5 seconds)
            delay(5000)
            updateOrderStatus(orderId, OrderStatus.ACCEPTED, 30)
            triggerNotification(
                title = "Order Accepted!",
                message = "Golden Grill chef has accepted your order $orderId and queueing ingredients.",
                type = "ORDER",
                orderId = orderId
            )

            // ACCEPTED -> PREPARING (8 seconds)
            delay(8000)
            updateOrderStatus(orderId, OrderStatus.PREPARING, 22)
            triggerNotification(
                title = "Kitchen is Crafting",
                message = "Your delicious burger or pizza order $orderId is sizzling on our hot grills!",
                type = "ORDER",
                orderId = orderId
            )

            // PREPARING -> READY_FOR_PICKUP (10 seconds)
            delay(10000)
            updateOrderStatus(orderId, OrderStatus.READY_FOR_PICKUP, 15)
            triggerNotification(
                title = "Order Packed & Hot",
                message = "The kitchen completed cooking order $orderId. A delivery driver has arrived to pick requested bags.",
                type = "ORDER",
                orderId = orderId
            )

            // READY_FOR_PICKUP -> OUT_FOR_DELIVERY (6 seconds)
            delay(6000)
            val driverNames = listOf("Alex Rider", "Jordan Miller", "Sam Higgins", "Ryan Parker", "Vikram Rathore")
            val selectedDriver = driverNames.random()
            val selectedPhone = "+1 (555) 482-${(1000..9999).random()}"

            // Generate driver start waypoint (offset from customer location)
            val orderRef = _orders.value.firstOrNull { it.id == orderId }
            val custLat = orderRef?.customerLat ?: 37.7749
            val custLng = orderRef?.customerLng ?: -122.4194

            updateOrderStatus(
                orderId = orderId,
                status = OrderStatus.OUT_FOR_DELIVERY,
                estMinutes = 12,
                driverName = selectedDriver,
                driverPhone = selectedPhone,
                driverLat = custLat + 0.015, // start coordinate offset of restaurant
                driverLng = custLng + 0.012
            )

            triggerNotification(
                title = "Out for Delivery!",
                message = "$selectedDriver has grabbed your food and is rushing over on a motor bike.",
                type = "DELIVERY",
                orderId = orderId
            )

            // Active Driver Movement Simulation (OUT_FOR_DELIVERY duration ~ 25 seconds of movement)
            val steps = 25
            var currentStep = 0
            val startLat = custLat + 0.015
            val startLng = custLng + 0.012

            while (currentStep <= steps) {
                delay(1000)
                val ratio = currentStep.toDouble() / steps.toDouble()
                val activeLat = startLat + (custLat - startLat) * ratio
                val activeLng = startLng + (custLng - startLng) * ratio
                val activeEst = (12 * (1.0 - ratio)).toInt().coerceAtLeast(1)

                updateDriverCoordinates(orderId, activeLat, activeLng, activeEst)
                currentStep++
            }

            // OUT_FOR_DELIVERY -> DELIVERED
            updateOrderStatus(orderId, OrderStatus.DELIVERED, 0)
            triggerNotification(
                title = "Order Delivered!",
                message = "Bon Appetit! Your food order $orderId has been delivered safely. Rate your food experience!",
                type = "DELIVERY",
                orderId = orderId
            )
        }
    }

    private fun updateOrderStatus(
        orderId: String,
        status: OrderStatus,
        estMinutes: Int,
        driverName: String? = null,
        driverPhone: String? = null,
        driverLat: Double? = null,
        driverLng: Double? = null
    ) {
        val updated = _orders.value.map { order ->
            if (order.id == orderId) {
                order.copy(
                    status = status,
                    estimatedMinutes = estMinutes,
                    driverName = driverName ?: order.driverName,
                    driverPhone = driverPhone ?: order.driverPhone,
                    driverLat = driverLat ?: order.driverLat,
                    driverLng = driverLng ?: order.driverLng
                )
            } else order
        }
        _orders.value = updated
        saveOrders()
    }

    private fun updateDriverCoordinates(orderId: String, lat: Double, lng: Double, estMinutes: Int) {
        val updated = _orders.value.map { order ->
            if (order.id == orderId) {
                order.copy(
                    driverLat = lat,
                    driverLng = lng,
                    estimatedMinutes = estMinutes
                )
            } else order
        }
        _orders.value = updated
    }

    private fun simulateLiveOrdersOnLaunch() {
        // Resume any pending or live simulator tasks
        _orders.value.forEach { order ->
            if (order.status != OrderStatus.DELIVERED && order.status != OrderStatus.CANCELLED) {
                startOrderTimelineSimulation(order.id)
            }
        }
    }

    // --- Reviews and Ratings ---
    fun addReview(foodItemId: String, rating: Double, comment: String, simulatedImageUri: String?) {
        val profileName = _currentUser.value?.fullName ?: "Anonymous Gourmet"
        val profileImage = _currentUser.value?.profilePhotoUrl
        val newReview = Review(
            id = "rev-${UUID.randomUUID()}",
            foodItemId = foodItemId,
            userName = profileName,
            rating = rating,
            comment = comment,
            imageUrl = simulatedImageUri,
            timestamp = System.currentTimeMillis()
        )

        val updatedReviews = listOf(newReview) + _reviews.value
        _reviews.value = updatedReviews
        saveReviews()
    }

    // --- Notifications Trigger ---
    fun triggerNotification(title: String, message: String, type: String, orderId: String? = null) {
        val newNotif = Notification(
            id = "notif-${UUID.randomUUID()}",
            title = title,
            message = message,
            type = type,
            orderId = orderId,
            timestamp = System.currentTimeMillis()
        )
        val updated = listOf(newNotif) + _notifications.value
        _notifications.value = updated
        saveNotifications()
    }

    // --- Dark Mode State Setter ---
    fun setDarkMode(enabled: Boolean) {
        _isDarkMode.value = enabled
        sharedPrefs.edit().putBoolean("theme_dark_mode", enabled).apply()
    }

    // --- Dynamic Foods Persistence ---
    private fun saveFoods() {
        val type = Types.newParameterizedType(List::class.java, FoodItem::class.java)
        val json = moshi.adapter<List<FoodItem>>(type).toJson(_foods.value)
        sharedPrefs.edit().putString("foods_v2", json).apply()
    }

    fun adminAddFoodItem(name: String, description: String, price: Double, categoryId: String, imageUrl: String) {
        val newId = "food_${UUID.randomUUID()}"
        val item = FoodItem(
            id = newId,
            name = name,
            description = description,
            price = price,
            imageUrl = imageUrl.ifBlank { "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&q=80" },
            rating = 5.0,
            reviewsCount = 0,
            categoryId = categoryId
        )
        val updated = _foods.value + item
        _foods.value = updated
        saveFoods()
    }

    fun adminRemoveFoodItem(id: String) {
        val updated = _foods.value.filter { it.id != id }
        _foods.value = updated
        saveFoods()
    }

    fun adminLoadPresets() {
        val defaults = listOf(
            FoodItem(
                id = "food_burger_preset",
                name = "Classic Double Smokehouse Burger",
                description = "Flame-grilled double beef patty, smoked cheddar, crispy onion rings, hickory BBQ sauce, and loaded garden greens.",
                price = 12.99,
                imageUrl = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500&q=80",
                rating = 4.8,
                reviewsCount = 142,
                categoryId = "cat_burgers"
            ),
            FoodItem(
                id = "food_pizza_preset",
                name = "Woodfired Truffle Sourdough Pizza",
                description = "Perfect sourdough crust, wild forest mushrooms, buffalo mozzarella, and premium white truffle glaze oil.",
                price = 16.49,
                imageUrl = "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500&q=80",
                rating = 4.9,
                reviewsCount = 312,
                categoryId = "cat_pizza"
            ),
            FoodItem(
                id = "food_sushi_preset",
                name = "Dragon Tempura Sushi Roll",
                description = "Crispy shrimp tempura, California avocado base, sliced dragon rolls, drizzled with unagi glaze and spicy dynamic aioli.",
                price = 15.99,
                imageUrl = "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=500&q=80",
                rating = 4.8,
                reviewsCount = 112,
                categoryId = "cat_sushi"
            ),
            FoodItem(
                id = "food_dessert_preset",
                name = "Warm Caramel Lava Cake",
                description = "Soft cocoa sponge cake baked with a beautiful molten butterscotch caramel interior. Dusted with fine sugar.",
                price = 6.99,
                imageUrl = "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=500&q=80",
                rating = 4.7,
                reviewsCount = 94,
                categoryId = "cat_desserts"
            ),
            FoodItem(
                id = "food_drink_preset",
                name = "Citrus Mint Mojito Mocktail",
                description = "Crushed aromatic key lime slices, muddled green mint, brown sugar, high-fizz tonic soda, and lots of ice.",
                price = 3.99,
                imageUrl = "https://images.unsplash.com/photo-1544145945-f90425340c7e?w=500&q=80",
                rating = 4.8,
                reviewsCount = 205,
                categoryId = "cat_drinks"
            )
        )
        _foods.value = defaults
        saveFoods()
    }

    companion object {
        @Volatile
        private var INSTANCE: FirebaseSimulator? = null

        fun getInstance(context: Context): FirebaseSimulator {
            return INSTANCE ?: synchronized(this) {
                val instance = FirebaseSimulator(context)
                INSTANCE = instance
                instance
            }
        }
    }
}
