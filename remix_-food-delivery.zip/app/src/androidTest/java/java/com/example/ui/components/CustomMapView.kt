package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.sqrt

// Coordinate helper to map lat/lng to container size
data class MapPoint(val lat: Double, val lng: Double)

@Composable
fun CustomMapView(
    modifier: Modifier = Modifier,
    isInteractive: Boolean = true, // Whether customer can drag the pin
    selectedLat: Double,
    selectedLng: Double,
    onLocationChanged: (Double, Double, String) -> Unit = { _, _, _ -> },
    driverLat: Double? = null,
    driverLng: Double? = null,
    restaurantLat: Double = 37.7885, // Default restaurant coordinates (SF SoMa)
    restaurantLng: Double = -122.4012
) {
    // Canvas dimensions bounding boxes
    var width by remember { mutableStateOf(300f) }
    var height by remember { mutableStateOf(200f) }

    // Map boundaries (roughly centering around San Francisco standard center)
    val minLat = 37.7600
    val maxLat = 37.8000
    val minLng = -122.4300
    val maxLng = -122.3900

    fun toCanvasCoords(lat: Double, lng: Double): Offset {
        val x = ((lng - minLng) / (maxLng - minLng)) * width
        // Reverse Y because canvas coordinates increase downwards
        val y = (1.0 - ((lat - minLat) / (maxLat - minLat))) * height
        return Offset(x.toFloat(), y.toFloat())
    }

    fun toLatLngCoords(offset: Offset): Pair<Double, Double> {
        val lng = minLng + (offset.x / width) * (maxLng - minLng)
        val lat = minLat + (1.0 - (offset.y / height)) * (maxLat - minLat)
        // Bound checks
        return Pair(
            lat.coerceIn(minLat, maxLat),
            lng.coerceIn(minLng, maxLng)
        )
    }

    // Translate coordinates to dummy text addresses
    fun getAddressFromLatLng(lat: Double, lng: Double): String {
        val hash = (lat * 10000 + lng * 10000).toInt() % 5
        return when (hash) {
            0 -> "452 Guerrero St, Mission District, San Francisco, CA"
            1 -> "185 Valencia St, Upper Market, San Francisco, CA"
            2 -> "108 Dolores St, Castro District, San Francisco, CA"
            3 -> "598 Market St, Financial District, San Francisco, CA"
            else -> "820 Folsom St, SoMa District, San Francisco, CA"
        }
    }

    // Remember coordinates
    val lastKnownLat = remember(selectedLat) { selectedLat }
    val lastKnownLng = remember(selectedLng) { selectedLng }

    Box(
        modifier = modifier
            .testTag("custom_map_container")
            .background(Color(0xFFE8F5E9), shape = RoundedCornerShape(16.dp)) // Light green garden layout background
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(isInteractive) {
                    if (!isInteractive) return@pointerInput
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val currentOffset = toCanvasCoords(lastKnownLat, lastKnownLng)
                        val newOffset = Offset(
                            (currentOffset.x + dragAmount.x).coerceIn(0f, width),
                            (currentOffset.y + dragAmount.y).coerceIn(0f, height)
                        )
                        val (newLat, newLng) = toLatLngCoords(newOffset)
                        val addressDesc = getAddressFromLatLng(newLat, newLng)
                        onLocationChanged(newLat, newLng, addressDesc)
                    }
                }
        ) {
            width = size.width
            height = size.height

            // --- Draw Map Features (Parks, Roads, Rivers, Grid lines) ---
            // Draw a big Park (Golden Gate Mock / Mission Park Mock)
            drawRoundRect(
                color = Color(0xFFA5D6A7), // Rich mossy green
                topLeft = Offset(width * 0.1f, height * 0.2f),
                size = Size(width * 0.35f, height * 0.4f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(16f, 16f)
            )

            // Draw Water Channel (San Francisco Bay Mock on Right)
            drawRect(
                color = Color(0xFFBBDEFB), // Bay Blue
                topLeft = Offset(width * 0.85f, 0f),
                size = Size(width * 0.15f, height)
            )

            // Grid Roads (Main Streets / Intersections)
            val streetStroke = Stroke(width = 6f)
            val highwayStroke = Stroke(width = 12f)
            val streetColor = Color(0xFFF5F5F5) // Solid white grey
            val highwayColor = Color(0xFFFFF59D) // Soft golden road

            // Vertical roads
            for (i in 1..4) {
                val gridX = width * (i * 0.2f)
                drawLine(
                    color = streetColor,
                    start = Offset(gridX, 0f),
                    end = Offset(gridX, height),
                    strokeWidth = streetStroke.width
                )
            }

            // Horizontal roads
            for (i in 1..4) {
                val gridY = height * (i * 0.2f)
                drawLine(
                    color = streetColor,
                    start = Offset(0f, gridY),
                    end = Offset(width, gridY),
                    strokeWidth = streetStroke.width
                )
            }

            // Draw a Major diagonal highway
            drawLine(
                color = highwayColor,
                start = Offset(0f, height * 0.9f),
                end = Offset(width * 0.9f, 0f),
                strokeWidth = highwayStroke.width
            )

            // Draw Transit path if tracking driver
            if (driverLat != null && driverLng != null) {
                val customerPos = toCanvasCoords(selectedLat, selectedLng)
                val restPos = toCanvasCoords(restaurantLat, restaurantLng)

                val mDottedEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)

                // Draw route line from restaurant to home
                drawLine(
                    color = Color(0xFFFF5722), // Gourmet Sunset Orange Route
                    start = restPos,
                    end = customerPos,
                    strokeWidth = 5f,
                    pathEffect = mDottedEffect
                )
            }
        }

        // --- Compose Overlay Components (Pins / Badges) ---
        // Restaurant Location Pin
        val restOffset = toCanvasCoords(restaurantLat, restaurantLng)
        MapPinOverlay(
            offset = restOffset,
            icon = Icons.Default.Restaurant,
            color = Color(0xFFFF5722), // Deep Orange
            label = "Gourmet Grill Hub"
        )

        // Customer Home Location Pin (Draggable)
        val customerOffset = toCanvasCoords(selectedLat, selectedLng)
        MapPinOverlay(
            offset = customerOffset,
            icon = Icons.Default.Home,
            color = Color(0xFF4CAF50), // Green Home Pin
            label = if (isInteractive) "Drag to Your Delivery House" else "Your Delivery House"
        )

        // Delivery Executive Icon
        if (driverLat != null && driverLng != null) {
            val driverOffset = toCanvasCoords(driverLat, driverLng)
            MapPinOverlay(
                offset = driverOffset,
                icon = Icons.Default.DirectionsBike,
                color = Color(0xFFFFB300), // Vibrant Driver Gold
                label = "Driver (Alex Rider)",
                isPulse = true
            )
        }

        // Map Title Indicator
        Box(
            modifier = Modifier
                .padding(12.dp)
                .background(Color.Black.copy(alpha = 0.7f), shape = RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
                .align(Alignment.TopStart)
        ) {
            Text(
                text = if (isInteractive) "📍 Drag Marker to Match Residence" else "🚚 Real-Time GPS Tracking",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // GPS Pulse Locate button
        if (isInteractive) {
            FloatingActionButton(
                onClick = {
                    // Force set to simulated Golden Gate Park/Downtown SF coords
                    onLocationChanged(37.7812, -122.4116, "598 Market St, Financial District, San Francisco, CA")
                },
                modifier = Modifier
                    .padding(12.dp)
                    .size(40.dp)
                    .align(Alignment.BottomEnd)
                    .testTag("use_location_button"),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MyLocation,
                    contentDescription = "Use My Current GPS Position",
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun BoxScope.MapPinOverlay(
    offset: Offset,
    icon: ImageVector,
    color: Color,
    label: String,
    isPulse: Boolean = false
) {
    Box(
        modifier = Modifier
            .offset(
                x = (offset.x / 1f).dp - 18.dp,
                y = (offset.y / 1f).dp - 36.dp
            ) // Offset alignment centering
            .size(42.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .background(color, shape = RoundedCornerShape(12.dp))
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
            // Little downward pin pointer indicator
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(color, shape = RoundedCornerShape(1.dp))
            )
        }
    }
}
