package com.example.data

import com.example.model.Category
import com.example.model.FoodItem

object FoodData {
    val categories = listOf(
        Category(
            id = "cat_burgers",
            name = "Burgers",
            imageUrl = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500&q=80"
        ),
        Category(
            id = "cat_pizza",
            name = "Pizzas",
            imageUrl = "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500&q=80"
        ),
        Category(
            id = "cat_sushi",
            name = "Sushi",
            imageUrl = "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=500&q=80"
        ),
        Category(
            id = "cat_desserts",
            name = "Desserts",
            imageUrl = "https://images.unsplash.com/photo-1551024601-bec78aea704b?w=500&q=80"
        ),
        Category(
            id = "cat_drinks",
            name = "Drinks",
            imageUrl = "https://images.unsplash.com/photo-1544145945-f90425340c7e?w=500&q=80"
        )
    )

    val foods = listOf(
        // Burgers
        FoodItem(
            id = "food_burger_1",
            name = "Double Cheese Smokehouse Burger",
            description = "Flame-grilled double beef patty, smoked cheddar, crispy onion rings, hickory BBQ sauce, and loaded garden greens on a toasted brioche bun.",
            price = 12.99,
            imageUrl = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500&q=80",
            rating = 4.8,
            reviewsCount = 142,
            categoryId = "cat_burgers"
        ),
        FoodItem(
            id = "food_burger_2",
            name = "Spicy Avocado Chicken Burger",
            description = "Crispy golden chicken breast fillet, sliced avocado, pepperjack cheese, jalapeño aioli, and shredded butter lettuce.",
            price = 10.49,
            imageUrl = "https://images.unsplash.com/photo-1525059696034-4967a8e1dca2?w=500&q=80",
            rating = 4.6,
            reviewsCount = 89,
            categoryId = "cat_burgers"
        ),
        FoodItem(
            id = "food_burger_3",
            name = "Plant-Based Truffle Mushroom Burger",
            description = "A juicy Beyond meat patty smothered in caramelized wild mushrooms, swiss cheese, and luxury truffle glaze mayonnaise.",
            price = 11.99,
            imageUrl = "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=500&q=80",
            rating = 4.7,
            reviewsCount = 76,
            categoryId = "cat_burgers"
        ),

        // Pizzas
        FoodItem(
            id = "food_pizza_1",
            name = "Supreme Garden Veggie Pizza",
            description = "Fresh vine-ripened tomato marinara sauce, loaded with kalamata olives, green bell peppers, mushrooms, sweet baby corn, red onions, and bubbly mozzarella.",
            price = 14.99,
            imageUrl = "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500&q=80",
            rating = 4.7,
            reviewsCount = 203,
            categoryId = "cat_pizza"
        ),
        FoodItem(
            id = "food_pizza_2",
            name = "Rustic Spicy Pepperoni & Basil",
            description = "Thin woodfired hand-stretched sourdough crust covered in spicy calabrese salami pepperoni, fresh basil, extra virgin olive oil, and grana padano.",
            price = 16.49,
            imageUrl = "https://images.unsplash.com/photo-1628840042765-356cda07504e?w=500&q=80",
            rating = 4.9,
            reviewsCount = 312,
            categoryId = "cat_pizza"
        ),
        FoodItem(
            id = "food_pizza_3",
            name = "Creamy White Truffle & Mushroom Pizza",
            description = "Creamy alfredo white sauce base, seasoned forest mushrooms, dynamic buffalo mozzarella, and premium white truffle oil drizzles.",
            price = 17.99,
            imageUrl = "https://images.unsplash.com/photo-1573821663912-569905455b1c?w=500&q=80",
            rating = 4.5,
            reviewsCount = 65,
            categoryId = "cat_pizza"
        ),

        // Sushi
        FoodItem(
            id = "food_sushi_1",
            name = "Imperial Dragon Sushi Platter",
            description = "Perfectly balanced sushi assortment featuring hand-rolled spicy tuna, crunchy shrimp tempura, California rolls, avocado nigiri, and fresh salmon sashimi.",
            price = 22.99,
            imageUrl = "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=500&q=80",
            rating = 4.9,
            reviewsCount = 188,
            categoryId = "cat_sushi"
        ),
        FoodItem(
            id = "food_sushi_2",
            name = "Glazed Salmon Aburi Roll",
            description = "Savory flame-seared fresh salmon rolls, crab stick interior, layered with unagi sweet glaze and dynamic spicy mayonnaise swirls.",
            price = 15.99,
            imageUrl = "https://images.unsplash.com/photo-1611143669185-af224c5e3252?w=500&q=80",
            rating = 4.8,
            reviewsCount = 112,
            categoryId = "cat_sushi"
        ),

        // Desserts
        FoodItem(
            id = "food_dessert_1",
            name = "Triple Chocolate Decadence Donut",
            description = "Soft, glazed chocolate cocoa donut topped with rich belgian white, milk, and dark chocolate chips, paired with chocolate ganache crust.",
            price = 4.99,
            imageUrl = "https://images.unsplash.com/photo-1551024601-bec78aea704b?w=500&q=80",
            rating = 4.9,
            reviewsCount = 422,
            categoryId = "cat_desserts"
        ),
        FoodItem(
            id = "food_dessert_2",
            name = "Warm Caramel Lava Cake",
            description = "Rich hot molten sponge cake detailing a rich flowing butterscotch caramel core, served with a dust of powdered sweet cocoa.",
            price = 6.99,
            imageUrl = "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=500&q=80",
            rating = 4.7,
            reviewsCount = 94,
            categoryId = "cat_desserts"
        ),

        // Drinks
        FoodItem(
            id = "food_drink_1",
            name = "Fresh Citrus Mint Mojito",
            description = "Thirst-quenching crushed key lime, organic raw cane sugar, hand-slapped fresh aromatic mint leaves, muddled with high-fizz tonic water overlay on ice.",
            price = 3.99,
            imageUrl = "https://images.unsplash.com/photo-1544145945-f90425340c7e?w=500&q=80",
            rating = 4.8,
            reviewsCount = 205,
            categoryId = "cat_drinks"
        ),
        FoodItem(
            id = "food_drink_2",
            name = "Double Roast Vanilla Macchiato",
            description = "Artisanal espresso pulled from robust light roasted beans, organic madagascar vanilla extract, frothy whole milk swirl, and buttery caramel crosshatches.",
            price = 4.49,
            imageUrl = "https://images.unsplash.com/photo-1541167760496-1628856ab772?w=500&q=80",
            rating = 4.6,
            reviewsCount = 139,
            categoryId = "cat_drinks"
        )
    )
}
