package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.FirebaseSimulator
import com.example.data.FoodData
import com.example.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class FoodAppViewModel(application: Application) : AndroidViewModel(application) {

    private val simulator = FirebaseSimulator.getInstance(application)

    // Reactively bridge all flows from the simulator
    val currentUser = simulator.currentUser
    val isDarkMode = simulator.isDarkMode
    val foods = simulator.foods
    val favorites = simulator.favorites
    val cart = simulator.cart
    val orders = simulator.orders
    val reviews = simulator.reviews
    val notifications = simulator.notifications
    val otpTimer = simulator.otpTimer

    // UI state flows
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategoryId = MutableStateFlow<String?>(null)
    val selectedCategoryId = _selectedCategoryId.asStateFlow()

    private val _selectedFoodId = MutableStateFlow<String?>(null)
    val selectedFoodId = _selectedFoodId.asStateFlow()

    private val _activeOrderIdForTracking = MutableStateFlow<String?>(null)
    val activeOrderIdForTracking = _activeOrderIdForTracking.asStateFlow()

    // Temporary registration values during onboarding
    val registrationPhoto = MutableStateFlow("https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&q=80")

    // Filter meals by search query and category
    val filteredFoods: StateFlow<List<FoodItem>> = combine(
        simulator.foods,
        searchQuery,
        selectedCategoryId,
        favorites
    ) { foodsList, query, catId, favs ->
        var list = foodsList
        if (catId != null) {
            list = list.filter { it.categoryId == catId }
        }
        if (query.isNotBlank()) {
            list = list.filter { it.name.contains(query, ignoreCase = true) || it.description.contains(query, ignoreCase = true) }
        }
        // Map elements to reflect accurate favorite flags
        list.map { it.copy(isFavorite = favs.contains(it.id)) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Grab currently focused food details
    val currentFoodItemState: StateFlow<FoodItem?> = combine(
        _selectedFoodId,
        simulator.foods,
        favorites
    ) { foodId, foodsList, favs ->
        val item = foodsList.firstOrNull { it.id == foodId }
        item?.copy(isFavorite = favs.contains(item.id))
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Current Tracking Order State
    val trackingOrder: StateFlow<Order?> = combine(
        _activeOrderIdForTracking,
        orders
    ) { orderId, list ->
        list.firstOrNull { it.id == orderId }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(1000), null)

    // Food ratings average calculator
    fun getRatingStatsForFood(foodId: String): Pair<Double, Int> {
        val list = reviews.value.filter { it.foodItemId == foodId }
        if (list.isEmpty()) {
            val item = simulator.foods.value.firstOrNull { it.id == foodId }
            return Pair(item?.rating ?: 5.0, item?.reviewsCount ?: 0)
        }
        val sum = list.sumOf { it.rating }
        return Pair(sum / list.size.toDouble(), list.size)
    }

    fun setDarkMode(enabled: Boolean) {
        simulator.setDarkMode(enabled)
    }

    fun adminAddFood(name: String, description: String, price: Double, categoryId: String, imageUrl: String) {
        simulator.adminAddFoodItem(name, description, price, categoryId, imageUrl)
    }

    fun adminRemoveFood(id: String) {
        simulator.adminRemoveFoodItem(id)
    }

    fun adminLoadPresets() {
        simulator.adminLoadPresets()
    }

    // Search query updation
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(catId: String?) {
        _selectedCategoryId.value = catId
    }

    fun selectFoodItem(foodId: String?) {
        _selectedFoodId.value = foodId
    }

    fun selectOrderForTracking(orderId: String?) {
        _activeOrderIdForTracking.value = orderId
    }

    // --- Simulator Intermediaries ---
    fun requestSmsOtp(mobile: String, onSent: (String) -> Unit) {
        simulator.sendFirebaseOtp(mobile, onSent)
    }

    fun resendSmsOtp(onSent: (String) -> Unit) {
        simulator.resendFirebaseOtp(onSent)
    }

    fun verifySmsOtp(code: String, onSuccess: (User) -> Unit, onFailure: (String) -> Unit) {
        simulator.verifyFirebaseOtp(code, onSuccess, onFailure)
    }

    fun registerOnboard(name: String, email: String, profilePic: String) {
        simulator.registerNewUser(name, email, profilePic)
    }

    fun logout() {
        _selectedCategoryId.value = null
        _selectedFoodId.value = null
        _activeOrderIdForTracking.value = null
        _searchQuery.value = ""
        simulator.logout()
    }

    fun updateProfile(name: String, email: String, photo: String, address: String, landmark: String) {
        simulator.updateProfile(name, email, photo, address, landmark)
    }

    fun toggleFavorite(foodId: String) {
        simulator.toggleFavorite(foodId)
    }

    fun addToCart(foodItem: FoodItem, qty: Int) {
        simulator.addToCart(foodItem, qty)
    }

    fun updateCartQuantity(foodId: String, delta: Int) {
        simulator.updateCartQuantity(foodId, delta)
    }

    fun removeCartItem(foodId: String) {
        simulator.removeCartItem(foodId)
    }

    fun checkoutAndPlaceOrder(
        fullName: String,
        mobile: String,
        address: String,
        landmark: String,
        notes: String,
        lat: Double,
        lng: Double
    ): Order {
        val obj = simulator.placeOrder(
            fullName,
            mobile,
            address,
            landmark,
            notes,
            lat,
            lng
        )
        _activeOrderIdForTracking.value = obj.id
        return obj
    }

    fun reorder(order: Order) {
        simulator.reorder(order)
    }

    fun addFoodReview(foodId: String, rating: Double, comment: String, imageUri: String? = null) {
        simulator.addReview(foodId, rating, comment, imageUri)
    }

    fun markNotificationsRead() {
        // Simple in-memory notification reading if desired
    }
}
