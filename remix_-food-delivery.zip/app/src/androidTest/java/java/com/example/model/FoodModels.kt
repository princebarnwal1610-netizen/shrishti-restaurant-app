package com.example.model

data class User(
    val mobile: String = "",
    val fullName: String = "",
    val email: String = "",
    val profilePhotoUrl: String = "",
    val isRegistered: Boolean = false,
    val defaultAddress: String = "",
    val defaultLandmark: String = ""
)

data class Category(
    val id: String,
    val name: String,
    val imageUrl: String
)

data class FoodItem(
    val id: String,
    val name: String,
    val description: String,
    val price: Double,
    val imageUrl: String,
    val rating: Double,
    val reviewsCount: Int,
    val categoryId: String,
    val isFavorite: Boolean = false
)

data class CartItem(
    val id: String,
    val foodItem: FoodItem,
    val quantity: Int
)

enum class OrderStatus {
    PENDING,
    ACCEPTED,
    PREPARING,
    READY_FOR_PICKUP,
    OUT_FOR_DELIVERY,
    DELIVERED,
    CANCELLED;

    fun displayName(): String = when (this) {
        PENDING -> "Order Placed"
        ACCEPTED -> "Order Accepted"
        PREPARING -> "Preparing Food"
        READY_FOR_PICKUP -> "Ready For Pickup"
        OUT_FOR_DELIVERY -> "Out For Delivery"
        DELIVERED -> "Delivered"
        CANCELLED -> "Cancelled"
    }
}

data class Order(
    val id: String,
    val items: List<CartItem>,
    val subtotal: Double,
    val deliveryCharges: Double,
    val total: Double,
    val name: String,
    val mobile: String,
    val deliveryAddress: String,
    val landmark: String,
    val notes: String,
    val status: OrderStatus,
    val timestamp: Long,
    val estimatedMinutes: Int,
    val driverName: String? = null,
    val driverPhone: String? = null,
    val driverLat: Double = 0.0,
    val driverLng: Double = 0.0,
    val customerLat: Double = 0.0,
    val customerLng: Double = 0.0
)

data class Review(
    val id: String,
    val foodItemId: String,
    val userName: String,
    val rating: Double,
    val comment: String,
    val imageUrl: String? = null,
    val timestamp: Long
)

data class Notification(
    val id: String,
    val title: String,
    val message: String,
    val type: String,
    val orderId: String? = null,
    val timestamp: Long,
    val isRead: Boolean = false
)
