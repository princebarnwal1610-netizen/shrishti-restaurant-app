package com.example

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.FoodAppNavigationContainer
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.FoodAppViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    instance = this
    enableEdgeToEdge()
    setContent {
      val viewModel: FoodAppViewModel = viewModel()
      val isDark by viewModel.isDarkMode.collectAsState()
      MyApplicationTheme(darkTheme = isDark, dynamicColor = false) {
        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
          FoodAppNavigationContainer(
              viewModel = viewModel,
              modifier = Modifier.padding(innerPadding)
          )
        }
      }
    }
  }

  companion object {
    private var instance: MainActivity? = null

    fun getAppContext(): Context {
      return instance!!.applicationContext
    }
  }
}
