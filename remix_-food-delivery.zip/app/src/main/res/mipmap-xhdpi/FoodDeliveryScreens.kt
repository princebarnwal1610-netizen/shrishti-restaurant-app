package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.FoodData
import com.example.model.*
import com.example.ui.components.CustomMapView
import com.example.ui.viewmodel.FoodAppViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

// --- MAIN ENTRANCE CONTROLLER ---
@Composable
fun FoodAppNavigationContainer(
    viewModel: FoodAppViewModel,
    modifier: Modifier = Modifier
) {
    var currentScreen by remember { mutableStateOf("splash") }
    val currentUserState by viewModel.currentUser.collectAsState()
    val trackingOrderId by viewModel.activeOrderIdForTracking.collectAsState()

    // Screen selection router
    Box(modifier = modifier.fillMaxSize()) {
        when (currentScreen) {
            "splash" -> SplashScreen(
                viewModel = viewModel,
                onNavigate = { route -> currentScreen = route }
            )
            "login" -> LoginScreen(
                viewModel = viewModel,
                onNavigateToOtp = { currentScreen = "otp" }
            )
            "otp" -> OtpScreen(
                viewModel = viewModel,
                onNavigate = { route -> currentScreen = route }
            )
            "register" -> RegisterScreen(
                viewModel = viewModel,
                onSuccess = { currentScreen = "main" }
            )
            "main" -> MainFrame(
                viewModel = viewModel,
                onNavigateToCategory = { currentScreen = "category" },
                onNavigateToFoodDetails = { currentScreen = "food_details" },
                onNavigateToCart = { currentScreen = "cart" },
                onNavigateToCheckout = { currentScreen = "checkout" },
                onNavigateToTracking = { currentScreen = "tracking" },
                onLogout = { currentScreen = "login" }
            )
            "category" -> CategoryScreen(
                viewModel = viewModel,
                onBack = { currentScreen = "main" },
                onNavigateToFoodDetails = { currentScreen = "food_details" }
            )
            "food_details" -> FoodDetailsScreen(
                viewModel = viewModel,
                onBack = { currentScreen = "main" }
            )
            "cart" -> CartScreen(
                viewModel = viewModel,
                onBack = { currentScreen = "main" },
                onNavigateToCheckout = { currentScreen = "checkout" }
            )
            "checkout" -> CheckoutScreen(
                viewModel = viewModel,
                onBack = { currentScreen = "cart" },
                onOrderPlaced = { currentScreen = "confirm" }
            )
            "confirm" -> OrderConfirmationScreen(
                viewModel = viewModel,
                onNavigateToTracking = { currentScreen = "tracking" },
                onBackToHome = { currentScreen = "main" }
            )
            "tracking" -> OrderTrackingScreen(
                viewModel = viewModel,
                onBack = { currentScreen = "main" }
            )
        }
    }
}

// ==========================================
// 1. SPLASH SCREEN
// ==========================================
@Composable
fun SplashScreen(
    viewModel: FoodAppViewModel,
    onNavigate: (String) -> Unit
) {
    val user by viewModel.currentUser.collectAsState()
    var rotateAnim by remember { mutableStateOf(0f) }

    LaunchedEffect(Unit) {
        // Simple delay before checking profiles
        delay(2600)
        when {
            user == null -> onNavigate("login")
            user?.isRegistered == false -> onNavigate("register")
            else -> onNavigate("main")
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("splash_screen")
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFFF5722), // Gourmet Sunset Orange
                        Color(0xFFE64A19)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Elegant Food Delivery Custom SVG Circle Logo
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .background(Color.White, shape = CircleShape)
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.RestaurantMenu,
                    contentDescription = "Gourmet Logo",
                    tint = Color(0xFFFF5722),
                    modifier = Modifier.size(70.dp)
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "Food Delivery",
                color = Color.White,
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Gourmet Meals • Real-Time Tracking • COD",
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(48.dp))
            CircularProgressIndicator(
                color = Color.White,
                strokeWidth = 3.dp,
                modifier = Modifier.size(30.dp)
                    .testTag("splash_loader")
            )
        }
    }
}

// ==========================================
// 2. AUTHENTICATION (LOGIN)
// ==========================================
@Composable
fun LoginScreen(
    viewModel: FoodAppViewModel,
    onNavigateToOtp: () -> Unit
) {
    var mobileNumber by remember { mutableStateOf("") }
    var selectedCountryCode by remember { mutableStateOf("+1") }
    var isCodeDropdownExpanded by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current

    val countryCodes = listOf("+1", "+91", "+44", "+971", "+61")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("login_screen")
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.DirectionsBike,
                contentDescription = "Riding Icon",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(72.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Let's Get Started",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Enter phone details for Firebase mobile authentication SMS verification",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(32.dp))

            // Country Selector & Input Field Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box {
                    OutlinedButton(
                        onClick = { isCodeDropdownExpanded = true },
                        modifier = Modifier.height(56.dp)
                            .testTag("country_code_selector"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(text = selectedCountryCode, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                    }
                    DropdownMenu(
                        expanded = isCodeDropdownExpanded,
                        onDismissRequest = { isCodeDropdownExpanded = false }
                    ) {
                        countryCodes.forEach { code ->
                            DropdownMenuItem(
                                text = { Text(code) },
                                onClick = {
                                    selectedCountryCode = code
                                    isCodeDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedTextField(
                    value = mobileNumber,
                    onValueChange = {
                        if (it.all { char -> char.isDigit() } && it.length <= 10) {
                            mobileNumber = it
                            errorText = null
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("mobile_input"),
                    label = { Text("Mobile Number") },
                    placeholder = { Text("10 digit number") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            }

            if (errorText != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = errorText!!,
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.Start)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    if (mobileNumber.length != 10) {
                        errorText = "Please enter a valid 10-digit mobile number"
                    } else {
                        viewModel.requestSmsOtp("$selectedCountryCode-$mobileNumber") { code ->
                            Toast.makeText(context, "Simulating Firebase verification... SMS Sent!", Toast.LENGTH_SHORT).show()
                            onNavigateToOtp()
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("continue_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(text = "Send OTP Code", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ==========================================
// 2. AUTHENTICATION (OTP VERIFICATION)
// ==========================================
@Composable
fun OtpScreen(
    viewModel: FoodAppViewModel,
    onNavigate: (String) -> Unit
) {
    var otpInput by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }
    val timer by viewModel.otpTimer.collectAsState()
    val context = LocalContext.current

    // Trigger auto-detect simulation delay of 3.5 seconds
    LaunchedEffect(Unit) {
        delay(3500)
        otpInput = "123456"
        Toast.makeText(context, "OTP code auto-detected!", Toast.LENGTH_SHORT).show()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("otp_screen")
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Shield Icon",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(72.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Enter 6-Digit OTP",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "We sent an authenticated mock Firebase passcode. Please wait for auto-detection or input code.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = otpInput,
                onValueChange = {
                    if (it.all { char -> char.isDigit() } && it.length <= 6) {
                        otpInput = it
                        errorText = null
                    }
                },
                modifier = Modifier
                    .width(200.dp)
                    .testTag("otp_input"),
                label = { Text("6 Digit OTP") },
                placeholder = { Text("XXXXXX") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                shape = RoundedCornerShape(12.dp),
                textStyle = LocalTextStyle.current.copy(textAlign = TextAlign.Center, letterSpacing = 3.sp, fontWeight = FontWeight.Bold),
                singleLine = true
            )

            if (errorText != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = errorText!!,
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Timer display & Resend trigger
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (timer > 0) {
                    Text(
                        text = "Resend OTP code in ${timer}s",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                    )
                } else {
                    TextButton(
                        onClick = {
                            viewModel.resendSmsOtp { 
                                Toast.makeText(context, "OTP Resent successfully!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.testTag("resend_otp_button")
                    ) {
                        Text(text = "Resend OTP", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    viewModel.verifySmsOtp(
                        code = otpInput,
                        onSuccess = { user ->
                            if (user.isRegistered) {
                                onNavigate("main")
                            } else {
                                onNavigate("register")
                            }
                        },
                        onFailure = { err -> errorText = err }
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("verify_otp_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(text = "Verify OTP", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ==========================================
// 2. NEW USER REGISTRATION SCREEN
// ==========================================
@Composable
fun RegisterScreen(
    viewModel: FoodAppViewModel,
    onSuccess: () -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var emailInput by remember { mutableStateOf("") }
    val selectedPhoto by viewModel.registrationPhoto.collectAsState()

    val presetAvatars = listOf(
        "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&q=80", // Boy avatar
        "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80", // Girl avatar
        "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=200&q=80", // Chef avatar
        "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&q=80"  // Foodie avatar
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("register_screen")
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "Complete Profile",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Onboarding for your first login experience",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
            Spacer(modifier = Modifier.height(24.dp))

            // Large Profile Pic selection
            AsyncImage(
                model = selectedPhoto,
                contentDescription = "Selected profile picture",
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape),
                contentScale = ContentScale.Crop
            )

            Spacer(modifier = Modifier.height(16.dp))
            Text(text = "Choose Foodie Avatar", fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            // Presets slider
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(presetAvatars) { photoUrl ->
                    val isChosen = selectedPhoto == photoUrl
                    AsyncImage(
                        model = photoUrl,
                        contentDescription = "Avatar alternative",
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .border(
                                if (isChosen) 3.dp else 1.dp,
                                if (isChosen) MaterialTheme.colorScheme.primary else Color.LightGray,
                                CircleShape
                            )
                            .clickable { viewModel.registrationPhoto.value = photoUrl },
                        contentScale = ContentScale.Crop
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("full_name_register"),
                label = { Text("Full Name*") },
                placeholder = { Text("Enter your full name") },
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = emailInput,
                onValueChange = { emailInput = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("email_register"),
                label = { Text("Email (Optional)") },
                placeholder = { Text("name@example.com") },
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(40.dp))

            Button(
                onClick = {
                    if (fullName.isNotBlank()) {
                        viewModel.registerOnboard(fullName, emailInput, selectedPhoto)
                        onSuccess()
                    }
                },
                enabled = fullName.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_continue_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(text = "Save & Continue", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ==========================================
// 3. MAIN TAB CONTAINER (HOME / FAVS / NOTIFS / ORDERS / PROFILE)
// ==========================================
@Composable
fun MainFrame(
    viewModel: FoodAppViewModel,
    onNavigateToCategory: (String) -> Unit,
    onNavigateToFoodDetails: (String) -> Unit,
    onNavigateToCart: () -> Unit,
    onNavigateToCheckout: () -> Unit,
    onNavigateToTracking: (String) -> Unit,
    onLogout: () -> Unit
) {
    var activeTab by remember { mutableStateOf(0) }
    val cartItems by viewModel.cart.collectAsState()
    val notificationList by viewModel.notifications.collectAsState()

    val countUnreadNotifs = notificationList.size // Or check read flags

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                modifier = Modifier.testTag("main_bottom_nav"),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 4.dp
            ) {
                NavigationBarItem(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    icon = { Icon(imageVector = if (activeTab == 0) Icons.Filled.Home else Icons.Outlined.Home, contentDescription = "Home") },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    icon = { Icon(imageVector = if (activeTab == 1) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, contentDescription = "Favorites") },
                    label = { Text("Favorites") }
                )
                NavigationBarItem(
                    selected = activeTab == 2,
                    onClick = { activeTab = 2 },
                    icon = {
                        Box {
                            Icon(imageVector = if (activeTab == 2) Icons.Filled.Notifications else Icons.Outlined.Notifications, contentDescription = "Notifications")
                            if (countUnreadNotifs > 0) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(Color.Red, shape = CircleShape)
                                        .align(Alignment.TopEnd)
                                )
                            }
                        }
                    },
                    label = { Text("Alerts") }
                )
                NavigationBarItem(
                    selected = activeTab == 3,
                    onClick = { activeTab = 3 },
                    icon = { Icon(imageVector = if (activeTab == 3) Icons.Filled.History else Icons.Outlined.History, contentDescription = "Order Timeline Log") },
                    label = { Text("Orders") }
                )
                NavigationBarItem(
                    selected = activeTab == 4,
                    onClick = { activeTab = 4 },
                    icon = { Icon(imageVector = if (activeTab == 4) Icons.Filled.Person else Icons.Outlined.Person, contentDescription = "Profile Settings") },
                    label = { Text("Profile") }
                )
            }
        },
        floatingActionButton = {
            if (activeTab == 0 && cartItems.isNotEmpty()) {
                val sumItems = cartItems.sumOf { it.quantity }
                ExtendedFloatingActionButton(
                    text = { Text("View Basket ($sumItems)", fontWeight = FontWeight.Bold) },
                    icon = { Icon(imageVector = Icons.Default.ShoppingCart, contentDescription = null) },
                    onClick = onNavigateToCart,
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("home_view_cart_fab")
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            when (activeTab) {
                0 -> HomeScreenTab(
                    viewModel = viewModel,
                    onNavigateToCategory = onNavigateToCategory,
                    onNavigateToFoodDetails = onNavigateToFoodDetails
                )
                1 -> FavoritesTabScreen(
                    viewModel = viewModel,
                    onNavigateToFoodDetails = onNavigateToFoodDetails
                )
                2 -> NotificationsTabScreen(
                    viewModel = viewModel,
                    onNavigateToTracking = onNavigateToTracking
                )
                3 -> HistoryTabScreen(
                    viewModel = viewModel,
                    onNavigateToTracking = onNavigateToTracking
                )
                4 -> ProfileTabScreen(
                    viewModel = viewModel,
                    onLogout = onLogout
                )
            }
        }
    }
}

// ==========================================
// 3(A). HOME SCREEN TAB
// ==========================================
@Composable
fun HomeScreenTab(
    viewModel: FoodAppViewModel,
    onNavigateToCategory: (String) -> Unit,
    onNavigateToFoodDetails: (String) -> Unit
) {
    val user by viewModel.currentUser.collectAsState()
    val query by viewModel.searchQuery.collectAsState()
    val foodsList by viewModel.filteredFoods.collectAsState()
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_tab_scroll")
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Welcoming header banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.85f)
                            )
                        ),
                        shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)
                    )
                    .padding(horizontal = 24.dp)
                    .padding(top = 24.dp, bottom = 32.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Deliver To",
                            color = Color.White.copy(alpha = 0.75f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = user?.defaultAddress?.ifBlank { "Choose delivery address" } ?: "Guerrero Street, SF",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Hello, ${user?.fullName?.split(" ")?.firstOrNull() ?: "Gourmet"}! 👋",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Craving something delicious today?",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 12.sp
                        )
                    }
                    AsyncImage(
                        model = user?.profilePhotoUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&q=80",
                        contentDescription = "User avatar icon",
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, Color.White, CircleShape),
                        contentScale = ContentScale.Crop
                    )
                }
            }
        }

        // Sticky Search Bar & Category carousel
        item {
            Column(modifier = Modifier.padding(24.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = viewModel::updateSearchQuery,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_search_bar"),
                    placeholder = { Text("Search delicious foods, pizza, burgers...") },
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "Clear search")
                            }
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Dynamic Categories Slider section
                Text(
                    text = "Browse Categories",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(12.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(FoodData.categories) { category ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .testTag("cat_tile_${category.id}")
                                .clickable {
                                    viewModel.selectCategory(category.id)
                                    onNavigateToCategory(category.id)
                                }
                        ) {
                            AsyncImage(
                                model = category.imageUrl,
                                contentDescription = category.name,
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(RoundedCornerShape(18.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = category.name,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                // Dynamic popular foods heading
                Text(
                    text = if (query.isNotBlank()) "Search Results" else "Chef's Featured Favorites",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }

        if (foodsList.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Restaurant Menu is Empty",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Food items will be added dynamically by an admin. Click below to quickly import delicious preset dishes to test!",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(18.dp))
                        Button(
                            onClick = {
                                viewModel.adminLoadPresets()
                                Toast.makeText(context, "Loaded gourmet menu presets!", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("Initialize Preset Menu Items", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        } else {
            // List Grid of popular food items
            items(foodsList) { item ->
                FoodCardRow(
                    item = item,
                    onClick = {
                        viewModel.selectFoodItem(item.id)
                        onNavigateToFoodDetails(item.id)
                    },
                    onQuickAdd = {
                        viewModel.addToCart(item, 1)
                        Toast.makeText(context, "${item.name} added to cart!", Toast.LENGTH_SHORT).show()
                    },
                    onFavoriteToggle = {
                        viewModel.toggleFavorite(item.id)
                    }
                )
            }
        }
    }
}

// Food Card horizontal lists display helper component
@Composable
fun FoodCardRow(
    item: FoodItem,
    onClick: () -> Unit,
    onQuickAdd: () -> Unit,
    onFavoriteToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 8.dp)
            .clickable(onClick = onClick)
            .testTag("food_row_card_${item.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = item.imageUrl,
                contentDescription = item.name,
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = item.description,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(text = item.rating.toString(), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "(${item.reviewsCount} reviews)", fontSize = 10.sp, color = Color.Gray)
                }
            }
            Spacer(modifier = Modifier.width(4.dp))
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.height(80.dp)
            ) {
                IconButton(
                    onClick = onFavoriteToggle,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = if (item.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Favorite Toggle",
                        tint = if (item.isFavorite) Color.Red else Color.LightGray
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "$${item.price}",
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = onQuickAdd,
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.primary, CircleShape)
                            .size(28.dp)
                            .testTag("quick_add_${item.id}"),
                        colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add to Cart", modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

// ==========================================
// 4. CATEGORY WISE FOODS LIST SCREEN
// ==========================================
@Composable
fun CategoryScreen(
    viewModel: FoodAppViewModel,
    onBack: () -> Unit,
    onNavigateToFoodDetails: (String) -> Unit
) {
    val selectedCatId by viewModel.selectedCategoryId.collectAsState()
    val categoryObj = FoodData.categories.firstOrNull { it.id == selectedCatId }
    val foodsInCat by viewModel.filteredFoods.collectAsState()

    Scaffold(
        topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
                title = { Text(text = categoryObj?.name ?: "Category Meals", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .testTag("category_scroll")
                .background(MaterialTheme.colorScheme.background)
        ) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                ) {
                    AsyncImage(
                        model = categoryObj?.imageUrl,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.4f))
                    )
                    Text(
                        text = categoryObj?.name ?: "Awesome selections",
                        color = Color.White,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier
                            .padding(24.dp)
                            .align(Alignment.BottomStart)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            if (foodsInCat.isEmpty()) {
                item {
                    Text("No foods found in this group yet")
                }
            }

            items(foodsInCat) { item ->
                FoodCardRow(
                    item = item,
                    onClick = {
                        viewModel.selectFoodItem(item.id)
                        onNavigateToFoodDetails(item.id)
                    },
                    onQuickAdd = {
                        viewModel.addToCart(item, 1)
                    },
                    onFavoriteToggle = {
                        viewModel.toggleFavorite(item.id)
                    }
                )
            }
        }
    }
}

// ==========================================
// 5. FOOD DETAILS SCREEN & REVIEWS SYSTEM
// ==========================================
@Composable
fun FoodDetailsScreen(
    viewModel: FoodAppViewModel,
    onBack: () -> Unit
) {
    val item by viewModel.currentFoodItemState.collectAsState()
    val reviewsList by viewModel.reviews.collectAsState()
    var orderQuantity by remember { mutableStateOf(1) }
    val context = LocalContext.current

    // Floating Review dialog states
    var showAddReviewDialog by remember { mutableStateOf(false) }
    var userRating by remember { mutableStateOf(5.0) }
    var userComment by remember { mutableStateOf("") }

    val foodIdRef = item?.id ?: ""
    val matchingReviews = reviewsList.filter { it.foodItemId == foodIdRef }
    val (calcAverage, calcCount) = viewModel.getRatingStatsForFood(foodIdRef)

    Scaffold(
        floatingActionButton = {
            if (item != null) {
                Button(
                    onClick = {
                        viewModel.addToCart(item!!, orderQuantity)
                        Toast.makeText(context, "Added $orderQuantity of ${item!!.name} to Cart!", Toast.LENGTH_SHORT).show()
                        onBack()
                    },
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .height(52.dp)
                        .padding(horizontal = 12.dp)
                        .testTag("details_add_to_cart_btn"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.ShoppingCart, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Add To Cart • $${String.format(Locale.US, "%.2f", item!!.price * orderQuantity)}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        },
        floatingActionButtonPosition = FabPosition.Center
    ) { innerPadding ->
        if (item == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Error Loading Meal Details")
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .testTag("details_scroll")
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Hero Image backdrop
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                ) {
                    AsyncImage(
                        model = item!!.imageUrl,
                        contentDescription = item!!.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    // Gradient overlay
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f))
                                )
                            )
                    )
                    // Header items back icon
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .padding(16.dp)
                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                            .align(Alignment.TopStart)
                    ) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }

                    // Favorite toggler
                    IconButton(
                        onClick = { viewModel.toggleFavorite(item!!.id) },
                        modifier = Modifier
                            .padding(16.dp)
                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                            .align(Alignment.TopEnd)
                    ) {
                        Icon(
                            imageVector = if (item!!.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "Favorite Toggle Details",
                            tint = if (item!!.isFavorite) Color.Red else Color.White
                        )
                    }
                }
            }

            // Core card statistics
            item {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = item!!.name,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$${item!!.price} per portion",
                            fontWeight = FontWeight.Black,
                            fontSize = 19.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        // Quantity counters
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(Color.LightGray.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            IconButton(
                                onClick = { if (orderQuantity > 1) orderQuantity-- },
                                modifier = Modifier.size(28.dp).testTag("details_qty_dec")
                            ) {
                                Icon(imageVector = Icons.Default.Remove, contentDescription = "Decrease count")
                            }
                            Text(
                                text = orderQuantity.toString(),
                                modifier = Modifier.padding(horizontal = 8.dp),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            IconButton(
                                onClick = { orderQuantity++ },
                                modifier = Modifier.size(28.dp).testTag("details_qty_inc")
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = "Increase count")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.4f))
                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Food Details",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = item!!.description,
                        fontSize = 13.sp,
                        lineHeight = 20.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f)
                    )

                    Spacer(modifier = Modifier.height(24.dp))
                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.4f))
                    Spacer(modifier = Modifier.height(16.dp))

                    // Reviews heading
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Gourmet Reviews (${calcCount})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Button(
                            onClick = { showAddReviewDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(30.dp).testTag("add_review_trigger")
                        ) {
                            Text("Rate Experience", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "★ ${String.format(Locale.US, "%.1f", calcAverage)} • Satisfied Foodies Ratings Index",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            // Reviews item lists mapping
            if (matchingReviews.isEmpty()) {
                item {
                    Text(
                        text = "No reviews yet. Be the first gourmet to review!",
                        modifier = Modifier.padding(horizontal = 24.dp),
                        fontSize = 12.sp,
                        color = Color.LightGray
                    )
                }
            } else {
                items(matchingReviews) { review ->
                    ReviewItemCard(review = review)
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp)) // Padding for bottom button bar
            }
        }
    }

    // Modal dialog to add custom rating experience
    if (showAddReviewDialog) {
        Dialog(onDismissRequest = { showAddReviewDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("add_review_dialog")
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Rate Gourmet Deliciousness",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Star stars ratings selector
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        for (starIndex in 1..5) {
                            val active = starIndex <= userRating
                            IconButton(
                                onClick = { userRating = starIndex.toDouble() },
                                modifier = Modifier
                                    .size(28.dp)
                                    .testTag("star_select_${starIndex}")
                            ) {
                                Icon(
                                    imageVector = if (active) Icons.Filled.Star else Icons.Outlined.StarRate,
                                    tint = if (active) MaterialTheme.colorScheme.secondary else Color.LightGray,
                                    contentDescription = "Star Select rating $starIndex"
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = userComment,
                        onValueChange = { userComment = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .testTag("review_comment"),
                        placeholder = { Text("Write your review (taste, presentation, packaging)...") },
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showAddReviewDialog = false }) {
                            Text("Dismiss", color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (userComment.isNotBlank()) {
                                    viewModel.addFoodReview(foodIdRef, userRating, userComment)
                                    Toast.makeText(context, "Review published!", Toast.LENGTH_SHORT).show()
                                    // Reset states
                                    userComment = ""
                                    userRating = 5.0
                                    showAddReviewDialog = false
                                }
                            },
                            enabled = userComment.isNotBlank(),
                            modifier = Modifier.testTag("submit_review_button")
                        ) {
                            Text("Submit Review")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReviewItemCard(review: Review) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 6.dp)
            .testTag("review_card_${review.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = review.userName, fontWeight = FontWeight.Bold, fontSize = 13.sp)

                Row {
                    for (i in 1..5) {
                        val isFilled = i <= review.rating.toInt()
                        Icon(
                            imageVector = if (isFilled) Icons.Filled.Star else Icons.Outlined.StarRate,
                            contentDescription = null,
                            tint = if (isFilled) MaterialTheme.colorScheme.secondary else Color.LightGray,
                            modifier = Modifier.size(11.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = review.comment,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
            )
        }
    }
}

// ==========================================
// 6. CART / VIEW BASKET SCREEN
// ==========================================
@Composable
fun CartScreen(
    viewModel: FoodAppViewModel,
    onBack: () -> Unit,
    onNavigateToCheckout: () -> Unit
) {
    val cartItems by viewModel.cart.collectAsState()
    val subtotal = cartItems.sumOf { it.foodItem.price * it.quantity }
    val freeDeliveryThreshold = 30.0
    val deliveryCharges = if (subtotal > freeDeliveryThreshold) 0.0 else 2.99
    val finalTotal = subtotal + deliveryCharges

    Scaffold(
        topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
                title = { Text(text = "My Cart Basket", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        bottomBar = {
            if (cartItems.isNotEmpty()) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(8.dp),
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Column(
                        modifier = Modifier
                            .padding(24.dp)
                            .navigationBarsPadding()
                    ) {
                        // Display charges summary
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Subtotal", fontSize = 13.sp, color = Color.Gray)
                            Text(text = "$${String.format(Locale.US, "%.2f", subtotal)}", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Delivery Charges", fontSize = 13.sp, color = Color.Gray)
                            val deliveryText = if (deliveryCharges == 0.0) "FREE" else "$${deliveryCharges}"
                            Text(
                                text = deliveryText,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (deliveryCharges == 0.0) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.4f))
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "Grand Total", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text(text = "$${String.format(Locale.US, "%.2f", finalTotal)}", fontSize = 21.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = onNavigateToCheckout,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("cart_proceed_btn"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(text = "Proceed To Checkout", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        if (cartItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
                    .testTag("empty_cart_view"),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.Fastfood, contentDescription = null, modifier = Modifier.size(72.dp), tint = Color.LightGray)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "Your Cart is Empty", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(text = "Add sizzling meals from home page to proceed!", fontSize = 13.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(onClick = onBack, shape = RoundedCornerShape(12.dp)) {
                        Text("Start Browsing Foods")
                    }
                }
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .testTag("cart_items_scroll")
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Free delivery progress marker
            item {
                if (subtotal < freeDeliveryThreshold) {
                    val needed = freeDeliveryThreshold - subtotal
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f))
                            .padding(horizontal = 24.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = "Add $${String.format(Locale.US, "%.2f", needed)} more to enjoy completely FREE delivery!",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }

            items(cartItems) { item ->
                CartItemRow(
                    cartItem = item,
                    onIncreaseCount = { viewModel.updateCartQuantity(item.foodItem.id, 1) },
                    onDecreaseCount = { viewModel.updateCartQuantity(item.foodItem.id, -1) },
                    onRemove = { viewModel.removeCartItem(item.foodItem.id) }
                )
            }
        }
    }
}

@Composable
fun CartItemRow(
    cartItem: CartItem,
    onIncreaseCount: () -> Unit,
    onDecreaseCount: () -> Unit,
    onRemove: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 6.dp)
            .testTag("cart_item_row_${cartItem.foodItem.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = cartItem.foodItem.imageUrl,
                contentDescription = null,
                modifier = Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = cartItem.foodItem.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "$${cartItem.foodItem.price} each",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(6.dp))

            // Quantity adjust row
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDecreaseCount, modifier = Modifier.size(24.dp).testTag("cart_dec_${cartItem.foodItem.id}")) {
                    Icon(imageVector = Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(16.dp))
                }
                Text(
                    text = cartItem.quantity.toString(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )
                IconButton(onClick = onIncreaseCount, modifier = Modifier.size(24.dp).testTag("cart_inc_${cartItem.foodItem.id}")) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                IconButton(onClick = onRemove, modifier = Modifier.size(24.dp).testTag("cart_remove_${cartItem.foodItem.id}")) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete item", tint = Color.LightGray, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

// ==========================================
// 7. CHECKOUT SCREEN (WITH VECTOR DRAG MAP)
// ==========================================
@Composable
fun CheckoutScreen(
    viewModel: FoodAppViewModel,
    onBack: () -> Unit,
    onOrderPlaced: () -> Unit
) {
    val userState by viewModel.currentUser.collectAsState()
    val cartItems by viewModel.cart.collectAsState()

    var fullName by remember { mutableStateOf(userState?.fullName ?: "") }
    var mobileNo by remember { mutableStateOf(userState?.mobile ?: "") }
    var deliveryAddress by remember { mutableStateOf(userState?.defaultAddress ?: "") }
    var landmark by remember { mutableStateOf(userState?.defaultLandmark ?: "") }
    var orderNotes by remember { mutableStateOf("") }

    // Map latitude / longitude coordinate positions
    var chosenLat by remember { mutableStateOf(37.7812) }
    var chosenLng by remember { mutableStateOf(-122.4116) }

    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    Scaffold(
        topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
                title = { Text(text = "Finalize Checkout", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            // Interactive custom vector Map Box
            Text(
                text = "Select Delivery Address Location",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Move map marker or press GPS locator to auto-resolve address",
                fontSize = 11.sp,
                color = Color.Gray
            )
            Spacer(modifier = Modifier.height(10.dp))

            // Map instance render
            CustomMapView(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                isInteractive = true,
                selectedLat = chosenLat,
                selectedLng = chosenLng,
                onLocationChanged = { lat, lng, textAddr ->
                    chosenLat = lat
                    chosenLng = lng
                    deliveryAddress = textAddr
                }
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Contact Form Inputs
            Text(
                text = "Contact Details",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it },
                label = { Text("Full Name*") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("checkout_name_input"),
                placeholder = { Text("Enter recipient name") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = mobileNo,
                onValueChange = { mobileNo = it },
                label = { Text("Mobile Number*") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("checkout_mobile_input"),
                placeholder = { Text("Phone number") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = deliveryAddress,
                onValueChange = { deliveryAddress = it },
                label = { Text("Delivery Address*") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .testTag("checkout_address_input"),
                placeholder = { Text("Full housing street details") },
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = landmark,
                onValueChange = { landmark = it },
                label = { Text("Landmark (Optional)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("checkout_landmark_input"),
                placeholder = { Text("Near mall, metro, park etc.") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = orderNotes,
                onValueChange = { orderNotes = it },
                label = { Text("Order Kitchen Notes (Optional)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("checkout_notes_input"),
                placeholder = { Text("Spicy, no celery, ring bell etc.") },
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider(color = Color.LightGray.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(16.dp))

            // Payment Mode Section
            Text(
                text = "Select Payment Option",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Cash on Delivery warning badge
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Cash On Delivery Only (COD)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "UPI/Debit cards suspended for network maintenance. Pay cash when rider arrives.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    if (fullName.isNotBlank() && mobileNo.isNotBlank() && deliveryAddress.isNotBlank()) {
                        viewModel.checkoutAndPlaceOrder(
                            fullName = fullName,
                            mobile = mobileNo,
                            address = deliveryAddress,
                            landmark = landmark,
                            notes = orderNotes,
                            lat = chosenLat,
                            lng = chosenLng
                        )
                        Toast.makeText(context, "Feast Order Placed successfully - COD", Toast.LENGTH_LONG).show()
                        onOrderPlaced()
                    } else {
                        Toast.makeText(context, "Please complete required (*) fields", Toast.LENGTH_SHORT).show()
                    }
                },
                enabled = fullName.isNotBlank() && mobileNo.isNotBlank() && deliveryAddress.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("checkout_place_order_btn"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(text = "Place Order (COD Only)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ==========================================
// 8. AFTER ORDER PLACED (CONFIRMATION SCREEN)
// ==========================================
@Composable
fun OrderConfirmationScreen(
    viewModel: FoodAppViewModel,
    onNavigateToTracking: () -> Unit,
    onBackToHome: () -> Unit
) {
    val trackingOrder by viewModel.trackingOrder.collectAsState()

    if (trackingOrder == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("confirmation_screen")
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.size(54.dp)
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "Order Placed Successfully!",
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Cash on Delivery. Food is being finalized.",
                fontSize = 13.sp,
                color = Color.Gray
            )
            Spacer(modifier = Modifier.height(28.dp))

            // Order Card specifics
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Order ID", fontSize = 12.sp, color = Color.Gray)
                        Text(text = trackingOrder!!.id, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Grand Total", fontSize = 12.sp, color = Color.Gray)
                        Text(text = "$${String.format(Locale.US, "%.2f", trackingOrder!!.total)}", fontSize = 13.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Address", fontSize = 12.sp, color = Color.Gray)
                        Text(
                            text = trackingOrder!!.deliveryAddress,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(0.7f),
                            textAlign = TextAlign.End
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Estimated Time", fontSize = 12.sp, color = Color.Gray)
                        Text(text = "${trackingOrder!!.estimatedMinutes} minutes", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            Button(
                onClick = onNavigateToTracking,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("track_order_btn"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.DirectionsBike, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Track Live Status", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onBackToHome,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("back_to_home_btn"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(text = "Back To Home Screen", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

// ==========================================
// 9. LIVE ORDER STATUS TRACKING (REAL-TIME UPDATES & MAP)
// ==========================================
@Composable
fun OrderTrackingScreen(
    viewModel: FoodAppViewModel,
    onBack: () -> Unit
) {
    val order by viewModel.trackingOrder.collectAsState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    // Modal dialogs for support simulated channels
    var supportDialogType by remember { mutableStateOf<String?>(null) } // "CALL_RIDER", "CALL_REST", "SMS_RIDER"
    var typedSmsMessage by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
                title = { Text(text = "Order Tracker Map", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (order == null) {
            Box(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.History, contentDescription = null, modifier = Modifier.size(60.dp), tint = Color.LightGray)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("No Active Tracking Orders", fontWeight = FontWeight.Bold)
                    Text("Check notifications or place a new order!", fontSize = 12.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = onBack, shape = RoundedCornerShape(12.dp)) {
                        Text("Explore Food Now")
                    }
                }
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .testTag("tracking_scroll")
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Live status tracker map
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                ) {
                    CustomMapView(
                        modifier = Modifier.fillMaxSize(),
                        isInteractive = false,
                        selectedLat = order!!.customerLat,
                        selectedLng = order!!.customerLng,
                        driverLat = if (order!!.status == OrderStatus.OUT_FOR_DELIVERY) order!!.driverLat else null,
                        driverLng = if (order!!.status == OrderStatus.OUT_FOR_DELIVERY) order!!.driverLng else null
                    )
                }
            }

            // Driver specifics card (only shown if Out For Delivery)
            if (order!!.status == OrderStatus.OUT_FOR_DELIVERY) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DirectionsBike,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = order!!.driverName ?: "Alex Rider",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Motor bike • ${order!!.driverPhone ?: "+1 (555) 482-1204"}",
                                    fontSize = 12.sp,
                                    color = Color.Gray
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Schedule, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Arriving in ${order!!.estimatedMinutes} mins",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                }
                            }

                            // Communications icons
                            Column {
                                IconButton(
                                    onClick = { supportDialogType = "CALL_RIDER" },
                                    modifier = Modifier
                                        .background(MaterialTheme.colorScheme.primary, CircleShape)
                                        .size(34.dp),
                                    colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White)
                                ) {
                                    Icon(imageVector = Icons.Default.Call, contentDescription = "Call rider", modifier = Modifier.size(16.dp))
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                IconButton(
                                    onClick = { supportDialogType = "SMS_RIDER" },
                                    modifier = Modifier
                                        .background(Color.LightGray.copy(alpha = 0.4f), CircleShape)
                                        .size(34.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Message, contentDescription = "SMS rider", modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }

            // Timeline title
            item {
                Column(modifier = Modifier.padding(horizontal = 24.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Order Timeline Log",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = order!!.id,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            // High custom stepper checklist updates
            items(OrderStatus.values()) { step ->
                if (step != OrderStatus.CANCELLED || order!!.status == OrderStatus.CANCELLED) {
                    val isActive = step == order!!.status
                    val isCompleted = step.ordinal < order!!.status.ordinal

                    TimelineStepperRow(
                        step = step,
                        isActive = isActive,
                        isCompleted = isCompleted
                    )
                }
            }

            // Restaurant contact support fallback
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    OutlinedButton(
                        onClick = { supportDialogType = "CALL_REST" },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Restaurant, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Contact Restaurant")
                    }
                    OutlinedButton(
                        onClick = {
                            Toast.makeText(context, "System invoice generation completed. File saved.", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Download Invoice")
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }

    // Dial Dialog simulated overlay
    if (supportDialogType != null) {
        Dialog(onDismissRequest = { supportDialogType = null }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    when (supportDialogType) {
                        "CALL_RIDER" -> {
                            Icon(imageVector = Icons.Default.DirectionsBike, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(text = "Call ${order!!.driverName ?: "Alex Rider"}", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(text = order!!.driverPhone ?: "+1 (555) 390-4820", fontSize = 13.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(24.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                                TextButton(onClick = { supportDialogType = null }) { Text("Cancel") }
                                Button(
                                    onClick = {
                                        Toast.makeText(context, "Simulating out-going phone dialer...", Toast.LENGTH_SHORT).show()
                                        supportDialogType = null
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                                ) {
                                    Text("Simulate Call")
                                }
                            }
                        }
                        "CALL_REST" -> {
                            Icon(imageVector = Icons.Default.Restaurant, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(text = "Call Gourmet Grill Kitchen", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(text = "+1 (800) FEAST-NOW", fontSize = 13.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(24.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                                TextButton(onClick = { supportDialogType = null }) { Text("Dismiss") }
                                Button(
                                    onClick = {
                                        Toast.makeText(context, "Simulating call to restaurant frontdesk...", Toast.LENGTH_SHORT).show()
                                        supportDialogType = null
                                    }
                                ) {
                                    Text("Dial Kitchen")
                                }
                            }
                        }
                        "SMS_RIDER" -> {
                            Text(text = "Chat with ${order!!.driverName ?: "Alex Rider"}", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = typedSmsMessage,
                                onValueChange = { typedSmsMessage = it },
                                placeholder = { Text("Ask rider where they are, delivery preferences...") },
                                modifier = Modifier.fillMaxWidth().height(90.dp),
                                shape = RoundedCornerShape(12.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                TextButton(onClick = { supportDialogType = null }) { Text("Dismiss") }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        if (typedSmsMessage.isNotBlank()) {
                                            Toast.makeText(context, "Simulated SMS sent: \"$typedSmsMessage\"", Toast.LENGTH_LONG).show()
                                            typedSmsMessage = ""
                                            supportDialogType = null
                                        }
                                    },
                                    enabled = typedSmsMessage.isNotBlank()
                                ) {
                                    Text("Send")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TimelineStepperRow(
    step: OrderStatus,
    isActive: Boolean,
    isCompleted: Boolean
) {
    val nodeColor = when {
        isActive -> MaterialTheme.colorScheme.primary
        isCompleted -> MaterialTheme.colorScheme.tertiary
        else -> Color.LightGray
    }

    val stepTitle = step.displayName()
    val stepDesc = when (step) {
        OrderStatus.PENDING -> "Your order is successfully registered and sent."
        OrderStatus.ACCEPTED -> "The kitchen verified ingredients queue."
        OrderStatus.PREPARING -> "Chef is baking details sizzling fresh!"
        OrderStatus.READY_FOR_PICKUP -> "Bags are packed in hot-foil containers."
        OrderStatus.OUT_FOR_DELIVERY -> "Rider is heading to your residence GPS."
        OrderStatus.DELIVERED -> "Handed safely. Enjoy your tasty meals!"
        OrderStatus.CANCELLED -> "The order was cancelled by restaurant administration."
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 6.dp)
            .testTag("timeline_row_${step.name}"),
        verticalAlignment = Alignment.Top
    ) {
        // Node dot and column wire
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(end = 16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(14.dp)
                    .background(nodeColor, CircleShape)
                    .border(
                        width = if (isActive) 3.dp else 0.dp,
                        color = if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.3f) else Color.Transparent,
                        shape = CircleShape
                    )
            )
            // Stepper wire connection
            Box(
                modifier = Modifier
                    .width(2.dp)
                    .height(34.dp)
                    .background(if (isCompleted) MaterialTheme.colorScheme.tertiary else Color.LightGray.copy(alpha = 0.4f))
            )
        }

        Column {
            Text(
                text = stepTitle,
                fontWeight = if (isActive) FontWeight.ExtraBold else FontWeight.Bold,
                fontSize = if (isActive) 14.sp else 13.sp,
                color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = stepDesc,
                fontSize = 11.sp,
                color = if (isActive) MaterialTheme.colorScheme.onBackground else Color.Gray,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

// ==========================================
// 10. HISTORY SCREEN TAB
// ==========================================
@Composable
fun HistoryTabScreen(
    viewModel: FoodAppViewModel,
    onNavigateToTracking: (String) -> Unit
) {
    val ordersList by viewModel.orders.collectAsState()
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("orders_history_tab")
            .background(MaterialTheme.colorScheme.background)
    ) {
        item {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    text = "My Order Log Book",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Observe previous culinary histories & live trajectories",
                    fontSize = 13.sp,
                    color = Color.Gray
                )
            }
        }

        if (ordersList.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.History, contentDescription = null, modifier = Modifier.size(54.dp), tint = Color.LightGray)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "No Order Records Found", fontWeight = FontWeight.Bold, color = Color.Gray)
                        Text(text = "Go to home screen and order some tasty meals!", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
            return@LazyColumn
        }

        items(ordersList) { order ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp)
                    .clickable {
                        viewModel.selectOrderForTracking(order.id)
                        onNavigateToTracking(order.id)
                    }
                    .testTag("order_history_card_${order.id}"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = order.id, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                        val statusColor = when (order.status) {
                            OrderStatus.DELIVERED -> MaterialTheme.colorScheme.tertiary
                            OrderStatus.CANCELLED -> MaterialTheme.colorScheme.error
                            else -> MaterialTheme.colorScheme.secondary
                        }
                        Box(
                            modifier = Modifier
                                .background(statusColor.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = order.status.displayName(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = statusColor)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Summarize items
                    val itemsSummary = order.items.joinToString { "${it.foodItem.name} (x${it.quantity})" }
                    Text(
                        text = itemsSummary,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.US).format(Date(order.timestamp)),
                        fontSize = 10.sp,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "$${String.format(Locale.US, "%.2f", order.total)} Total", fontWeight = FontWeight.Black, fontSize = 15.sp)

                        Row {
                            TextButton(
                                onClick = {
                                    viewModel.reorder(order)
                                    Toast.makeText(context, "Items added back to basket. Go to Cart!", Toast.LENGTH_LONG).show()
                                },
                                contentPadding = PaddingValues(horizontal = 12.dp),
                                modifier = Modifier.testTag("reorder_btn_${order.id}")
                            ) {
                                Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Reorder", fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            Button(
                                onClick = {
                                    viewModel.selectOrderForTracking(order.id)
                                    onNavigateToTracking(order.id)
                                },
                                contentPadding = PaddingValues(horizontal = 12.dp),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(32.dp).testTag("track_btn_${order.id}")
                            ) {
                                Text("Track Status", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 10(A). FAVORITES SCREEN TAB
// ==========================================
@Composable
fun FavoritesTabScreen(
    viewModel: FoodAppViewModel,
    onNavigateToFoodDetails: (String) -> Unit
) {
    val favoritesIds by viewModel.favorites.collectAsState()
    val allFoods by viewModel.foods.collectAsState()
    val favMeals = allFoods.filter { favoritesIds.contains(it.id) }.map { it.copy(isFavorite = true) }
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("favorites_tab_scroll")
            .background(MaterialTheme.colorScheme.background)
    ) {
        item {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    text = "My Starred Favorites",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Quick access to your absolute gourmet favorites",
                    fontSize = 13.sp,
                    color = Color.Gray
                )
            }
        }

        if (favMeals.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Outlined.FavoriteBorder, contentDescription = null, modifier = Modifier.size(54.dp), tint = Color.LightGray)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "No Starred Foods Saved", fontWeight = FontWeight.Bold, color = Color.Gray)
                        Text(text = "Tap the heart on meal details to save here!", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
            return@LazyColumn
        }

        items(favMeals) { item ->
            FoodCardRow(
                item = item,
                onClick = {
                    viewModel.selectFoodItem(item.id)
                    onNavigateToFoodDetails(item.id)
                },
                onQuickAdd = {
                    viewModel.addToCart(item, 1)
                    Toast.makeText(context, "${item.name} ready in basket!", Toast.LENGTH_SHORT).show()
                },
                onFavoriteToggle = {
                    viewModel.toggleFavorite(item.id)
                }
            )
        }
    }
}

// ==========================================
// 11. NOTIFICATIONS TAB SCREEN
// ==========================================
@Composable
fun NotificationsTabScreen(
    viewModel: FoodAppViewModel,
    onNavigateToTracking: (String) -> Unit
) {
    val notificationsList by viewModel.notifications.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("notifications_list_tab")
            .background(MaterialTheme.colorScheme.background)
    ) {
        item {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    text = "Push Inbox Alerts",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Simulated Firebase Cloud Messaging (FCM) live timeline",
                    fontSize = 13.sp,
                    color = Color.Gray
                )
            }
        }

        if (notificationsList.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.NotificationsNone, contentDescription = null, modifier = Modifier.size(54.dp), tint = Color.LightGray)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "No Messages In Inbox", fontWeight = FontWeight.Bold, color = Color.Gray)
                    }
                }
            }
            return@LazyColumn
        }

        items(notificationsList) { notif ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 6.dp)
                    .clickable {
                        if (notif.orderId != null) {
                            viewModel.selectOrderForTracking(notif.orderId)
                            onNavigateToTracking(notif.orderId)
                        }
                    }
                    .testTag("notif_row_${notif.id}"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val notifIcon = when (notif.type) {
                        "ORDER" -> Icons.Default.ShoppingCart
                        "DELIVERY" -> Icons.Default.DirectionsBike
                        "SYSTEM" -> Icons.Default.Lock
                        else -> Icons.Default.Star
                    }
                    val iconColor = when (notif.type) {
                        "ORDER" -> MaterialTheme.colorScheme.primary
                        "DELIVERY" -> MaterialTheme.colorScheme.tertiary
                        else -> MaterialTheme.colorScheme.secondary
                    }

                    Box(
                        modifier = Modifier
                            .background(iconColor.copy(alpha = 0.15f), CircleShape)
                            .size(42.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = notifIcon, contentDescription = null, tint = iconColor, modifier = Modifier.size(20.dp))
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = notif.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(text = notif.message, fontSize = 11.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = SimpleDateFormat("h:mm a", Locale.US).format(Date(notif.timestamp)),
                            fontSize = 9.sp,
                            color = Color.LightGray
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// 12. PROFILE TAB (EDIT PROFILE, AVATAR, LOGOUT)
// ==========================================
@Composable
fun ProfileTabScreen(
    viewModel: FoodAppViewModel,
    onLogout: () -> Unit
) {
    val userState by viewModel.currentUser.collectAsState()
    val context = LocalContext.current

    var editName by remember { mutableStateOf(userState?.fullName ?: "") }
    var editEmail by remember { mutableStateOf(userState?.email ?: "") }
    var editAddress by remember { mutableStateOf(userState?.defaultAddress ?: "") }
    var editLandmark by remember { mutableStateOf(userState?.defaultLandmark ?: "") }

    var isEditMode by remember { mutableStateOf(false) }
    var showAvatarLibrary by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("profile_tab_screen")
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 24.dp)
    ) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.clickable { showAvatarLibrary = true }
                ) {
                    AsyncImage(
                        model = userState?.profilePhotoUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&q=80",
                        contentDescription = "Profile Pic",
                        modifier = Modifier
                            .size(96.dp)
                            .clip(CircleShape)
                            .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape),
                        contentScale = ContentScale.Crop
                    )
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(MaterialTheme.colorScheme.primary, CircleShape)
                            .align(Alignment.BottomEnd)
                            .border(1.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Change Logo",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = userState?.fullName ?: "Gourmet Guest",
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = userState?.mobile ?: "+1 (555) 000-0000",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 2.dp)
                ) {
                    Text(text = "🔥 Platinum Foodie Member", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                }

                Spacer(modifier = Modifier.height(4.dp))
                TextButton(onClick = { showAvatarLibrary = true }) {
                    Icon(imageVector = Icons.Default.Face, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Change Avatar from Library", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("profile_details_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "My Profile Data", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        TextButton(onClick = {
                            if (isEditMode) {
                                // Save
                                viewModel.updateProfile(editName, editEmail, userState?.profilePhotoUrl ?: "", editAddress, editLandmark)
                                Toast.makeText(context, "Saved Profile data successfully!", Toast.LENGTH_SHORT).show()
                            }
                            isEditMode = !isEditMode
                        }) {
                            Text(text = if (isEditMode) "Save Changes" else "Edit Details", fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (!isEditMode) {
                        ProfileInfoItem(label = "Full Name", value = userState?.fullName ?: "")
                        ProfileInfoItem(label = "Email Address", value = userState?.email?.ifBlank { "Not Specified" } ?: "Not Specified")
                        ProfileInfoItem(label = "Default Residence", value = userState?.defaultAddress?.ifBlank { "None Saved" } ?: "None Saved")
                        ProfileInfoItem(label = "Saved Landmark", value = userState?.defaultLandmark?.ifBlank { "None Saved" } ?: "None Saved")
                    } else {
                        OutlinedTextField(
                            value = editName,
                            onValueChange = { editName = it },
                            label = { Text("Name") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = editEmail,
                            onValueChange = { editEmail = it },
                            label = { Text("Email (Optional)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = editAddress,
                            onValueChange = { editAddress = it },
                            label = { Text("Default Delivery Address") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = editLandmark,
                            onValueChange = { editLandmark = it },
                            label = { Text("Landmark Shortcut") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )
                    }
                }
            }
        }

        // App Settings, Dark mode, and Dynamic Manager Panel Console
        item {
            Spacer(modifier = Modifier.height(16.dp))
            val isDark by viewModel.isDarkMode.collectAsState()
            var showAdminPanel by remember { mutableStateOf(false) }

            Card(
                modifier = Modifier.fillMaxWidth().testTag("app_settings_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "App Control Center", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Dark Mode Toggle Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isDark) Icons.Default.Star else Icons.Default.StarBorder,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("Premium Dark Appearance", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text(if (isDark) "Night mode active" else "Day beauty active", fontSize = 10.sp, color = Color.Gray)
                            }
                        }
                        Switch(
                            checked = isDark,
                            onCheckedChange = { viewModel.setDarkMode(it) }
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    Spacer(modifier = Modifier.height(12.dp))

                    // Store Console Toggle Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showAdminPanel = !showAdminPanel },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("Store Manager Console", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("Manage dynamic menus and food products", fontSize = 10.sp, color = Color.Gray)
                            }
                        }
                        Icon(
                            imageVector = if (showAdminPanel) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                            contentDescription = null,
                            tint = Color.Gray
                        )
                    }

                    if (showAdminPanel) {
                        Spacer(modifier = Modifier.height(16.dp))

                        var newFoodName by remember { mutableStateOf("") }
                        var newFoodDesc by remember { mutableStateOf("") }
                        var newFoodPrice by remember { mutableStateOf("") }
                        var selectedCatId by remember { mutableStateOf("cat_burgers") }
                        var newFoodImgUrl by remember { mutableStateOf("https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500&q=80") }

                        Text("Add New Gourmet Dish", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = newFoodName,
                            onValueChange = { newFoodName = it },
                            label = { Text("Dish Name") },
                            modifier = Modifier.fillMaxWidth(),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = newFoodDesc,
                            onValueChange = { newFoodDesc = it },
                            label = { Text("Description") },
                            modifier = Modifier.fillMaxWidth(),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                            shape = RoundedCornerShape(8.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = newFoodPrice,
                            onValueChange = { newFoodPrice = it },
                            label = { Text("Price (e.g. 12.99)") },
                            modifier = Modifier.fillMaxWidth(),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Text("Category Assignment:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(6.dp))

                        // Category selector chips!
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FoodData.categories.forEach { cat ->
                                val isChosen = selectedCatId == cat.id
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (isChosen) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = if (isChosen) Color.Transparent else Color.LightGray,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable {
                                            selectedCatId = cat.id
                                            // Assign beautiful Unsplash default URL
                                            newFoodImgUrl = when(cat.id) {
                                                "cat_burgers" -> "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500&q=80"
                                                "cat_pizza" -> "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500&q=80"
                                                "cat_sushi" -> "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=500&q=80"
                                                "cat_desserts" -> "https://images.unsplash.com/photo-1551024601-bec78aea704b?w=500&q=80"
                                                "cat_drinks" -> "https://images.unsplash.com/photo-1544145945-f90425340c7e?w=500&q=80"
                                                else -> "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&q=80"
                                            }
                                        }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = cat.name,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isChosen) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = newFoodImgUrl,
                            onValueChange = { newFoodImgUrl = it },
                            label = { Text("Image URL") },
                            modifier = Modifier.fillMaxWidth(),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp),
                            shape = RoundedCornerShape(8.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                val priceVal = newFoodPrice.toDoubleOrNull()
                                if (newFoodName.isBlank()) {
                                    Toast.makeText(context, "Please enter a valid dish name!", Toast.LENGTH_SHORT).show()
                                } else if (priceVal == null || priceVal <= 0.0) {
                                    Toast.makeText(context, "Please enter a valid numeric price!", Toast.LENGTH_SHORT).show()
                                } else {
                                    viewModel.adminAddFood(
                                        name = newFoodName,
                                        description = newFoodDesc,
                                        price = priceVal,
                                        categoryId = selectedCatId,
                                        imageUrl = newFoodImgUrl
                                    )
                                    Toast.makeText(context, "Dish added dynamically by Admin!", Toast.LENGTH_SHORT).show()
                                    newFoodName = ""
                                    newFoodDesc = ""
                                    newFoodPrice = ""
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Publish Dish to App Menu", fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        val currentFoods by viewModel.foods.collectAsState()
                        if (currentFoods.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Current Dynamic Menu Items (${currentFoods.size})", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(8.dp))

                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                currentFoods.forEach { dish ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
                                            .padding(8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                            AsyncImage(
                                                model = dish.imageUrl,
                                                contentDescription = dish.name,
                                                modifier = Modifier.size(36.dp).clip(RoundedCornerShape(4.dp)),
                                                contentScale = ContentScale.Crop
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(dish.name, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Text("$${dish.price}", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        IconButton(
                                            onClick = {
                                                viewModel.adminRemoveFood(dish.id)
                                                Toast.makeText(context, "Deleted ${dish.name}", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Delete",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = {
                                viewModel.adminLoadPresets()
                                Toast.makeText(context, "Initialized menu with defaults!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Load Preset Foods List", fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
            OutlinedButton(
                onClick = {
                    viewModel.logout()
                    onLogout()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("logout_button_nav"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error)
            ) {
                Icon(imageVector = Icons.Default.ExitToApp, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sign Out of Account", fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(48.dp))
        }
    }

    if (showAvatarLibrary) {
        Dialog(onDismissRequest = { showAvatarLibrary = false }) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Chef Avatar Library",
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Pick an aesthetic profile look matching your taste!",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(20.dp))

                    val avatarPresets = listOf(
                        Pair("Organic Foodie", "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80"),
                        Pair("Chef Sunset", "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=200&q=80"),
                        Pair("Gourmet Kid", "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&q=80"),
                        Pair("Aesthetic Critic", "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&q=80"),
                        Pair("Pastry Lover", "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&q=80"),
                        Pair("Brew Artisan", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80"),
                        Pair("Sushi Guru", "https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=200&q=80"),
                        Pair("Burger fan", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80")
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        for (i in 0 until avatarPresets.size step 2) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                for (j in 0..1 step 1) {
                                    val index = i + j
                                    if (index < avatarPresets.size) {
                                        val avatar = avatarPresets[index]
                                        Card(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clickable {
                                                    viewModel.updateProfile(
                                                        name = userState?.fullName ?: "Gourmet Guest",
                                                        email = userState?.email ?: "",
                                                        photo = avatar.second,
                                                        address = userState?.defaultAddress ?: "",
                                                        landmark = userState?.defaultLandmark ?: ""
                                                    )
                                                    showAvatarLibrary = false
                                                    Toast.makeText(context, "Adopted ${avatar.first} style!", Toast.LENGTH_SHORT).show()
                                                },
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                            border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(10.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally
                                            ) {
                                                AsyncImage(
                                                    model = avatar.second,
                                                    contentDescription = avatar.first,
                                                    modifier = Modifier.size(54.dp).clip(CircleShape),
                                                    contentScale = ContentScale.Crop
                                                )
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = avatar.first,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    TextButton(onClick = { showAvatarLibrary = false }) {
                        Text("Cancel Selection", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileInfoItem(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 8.dp)) {
        Text(text = label, fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
        Text(text = value, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
    }
}
